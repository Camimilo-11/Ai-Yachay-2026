"""Allowlist egress proxy for evigate's agent containers.

Agent containers sit on an internal Docker network with no route out. This proxy is the only way out: it
accepts HTTP CONNECT to port 443 of the hosts in $ALLOW (exact host or a subdomain of it) and refuses
everything else. Every decision is logged to stdout (`docker logs evigate-proxy`).
"""
import asyncio
import os
import sys
import time

ALLOW = [h.strip().lower() for h in os.environ.get("ALLOW", "").split(",") if h.strip()]
PORT = int(os.environ.get("PORT", "3128"))


def allowed(host: str, port: int) -> bool:
    host = host.lower().rstrip(".")
    return port == 443 and any(host == a or host.endswith("." + a) for a in ALLOW)


def log(*parts):
    print(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), *parts, flush=True)


async def pipe(reader, writer):
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except (ConnectionError, asyncio.CancelledError):
        pass
    finally:
        try:
            writer.close()
        except Exception:  # noqa: BLE001
            pass


async def handle(reader, writer):
    peer = writer.get_extra_info("peername")
    try:
        head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=30)
    except Exception:  # noqa: BLE001
        writer.close()
        return
    first = head.split(b"\r\n", 1)[0].decode("latin-1", "replace")
    parts = first.split()
    if len(parts) < 2 or parts[0].upper() != "CONNECT":
        log("DENY", peer, first[:120], "(only CONNECT is supported)")
        writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
        await writer.drain()
        writer.close()
        return
    host, _, port = parts[1].rpartition(":")
    port = int(port) if port.isdigit() else 443
    if not allowed(host, port):
        log("DENY", peer, f"{host}:{port}")
        writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
        await writer.drain()
        writer.close()
        return
    try:
        up_r, up_w = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=30)
    except Exception as e:  # noqa: BLE001
        log("FAIL", peer, f"{host}:{port}", type(e).__name__)
        writer.write(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
        await writer.drain()
        writer.close()
        return
    log("ALLOW", peer, f"{host}:{port}")
    writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
    await writer.drain()
    await asyncio.gather(pipe(reader, up_w), pipe(up_r, writer))


async def main():
    if not ALLOW:
        print("ALLOW is empty: refusing to start an open proxy", file=sys.stderr)
        sys.exit(2)
    server = await asyncio.start_server(handle, "0.0.0.0", PORT)
    log("listening on", PORT, "allow:", ",".join(ALLOW))
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
