"""Docker setup for the sandbox: image, internal network and the allowlist egress proxy, plus a self-test."""
from __future__ import annotations

import subprocess
import sys

from .evidence import PACKAGE_ROOT

IMAGE = "evigate-sandbox:0.1"
NETWORK = "evigate_int"
PROXY = "evigate-proxy"
PROXY_IMAGE = "python:3.12-slim-bookworm"
ALLOW = "api.anthropic.com,chatgpt.com,auth.openai.com,api.openai.com"


def _run(argv, check=True, quiet=False):
    if not quiet:
        print("$", " ".join(argv))
    cp = subprocess.run(argv, capture_output=True, text=True)
    if check and cp.returncode != 0:
        print(cp.stdout[-2000:], cp.stderr[-2000:], file=sys.stderr)
        raise SystemExit(f"command failed: {' '.join(argv)}")
    return cp


def setup(rebuild: bool = False) -> int:
    docker_dir = PACKAGE_ROOT / "docker"
    have = _run(["docker", "image", "inspect", IMAGE], check=False, quiet=True).returncode == 0
    if rebuild or not have:
        _run(["docker", "build", "-t", IMAGE, "-f", str(docker_dir / "Dockerfile"), str(docker_dir)])
    if _run(["docker", "network", "inspect", NETWORK], check=False, quiet=True).returncode != 0:
        _run(["docker", "network", "create", "--internal", NETWORK])
    _run(["docker", "rm", "-f", PROXY], check=False, quiet=True)
    _run(["docker", "run", "-d", "--name", PROXY, "--restart", "unless-stopped",
          "--read-only", "--cap-drop", "ALL", "--memory", "256m", "-e", f"ALLOW={ALLOW}",
          "-v", f"{docker_dir / 'egress_proxy.py'}:/proxy.py:ro", PROXY_IMAGE, "python", "-u", "/proxy.py"])
    _run(["docker", "network", "connect", NETWORK, PROXY])
    return selftest()


def selftest() -> int:
    """From the agent network: the model API must be reachable and everything else must be refused."""
    code = ("import urllib.request,sys\n"
            "def probe(u):\n"
            "  try:\n"
            "    urllib.request.urlopen(u, timeout=15); return 'open'\n"
            "  except urllib.error.HTTPError as e: return f'http {e.code}'\n"
            "  except Exception as e: return type(e).__name__\n"
            "for u in sys.argv[1:]: print(u, '->', probe(u))\n")
    urls = ["https://api.anthropic.com/", "https://pypi.org/simple/", "https://github.com/"]
    cp = _run(["docker", "run", "--rm", "--network", NETWORK,
               "-e", f"HTTPS_PROXY=http://{PROXY}:3128", "-e", f"HTTP_PROXY=http://{PROXY}:3128",
               IMAGE, "python", "-c", code, *urls], check=False)
    print(cp.stdout.strip())

    def results(text):
        out = {}
        for line in text.strip().splitlines():
            if " -> " in line:
                u, r = line.split(" -> ", 1)
                out[u.strip()] = r.strip()
        return out

    def reached(r):            # any HTTP answer, even an error status, means the host was reachable
        return r == "open" or r.startswith("http")

    got = results(cp.stdout)
    api_ok = reached(got.get(urls[0], ""))
    blocked = all(u in got and not reached(got[u]) for u in urls[1:])
    none_cp = _run(["docker", "run", "--rm", "--network", "none", IMAGE, "python", "-c", code, urls[1]],
                   check=False, quiet=True)
    print("network none:", none_cp.stdout.strip())
    none_blocked = all(not reached(r) for r in results(none_cp.stdout).values()) and bool(results(none_cp.stdout))
    ok = api_ok and blocked and none_blocked
    print("[evigate] sandbox self-test:", "OK" if ok else "FAILED")
    return 0 if ok else 1
