"""Build the project's environment for any Python repository.

Inputs are only what a user of any project could give: the code itself, and optionally a Python version,
a constraints file (a lock of dependency versions) and a cut-off date for dependency releases. Nothing
here knows about any benchmark.

The build runs once per case in a container with normal egress (network "setup"); no agent runs there.
The project is installed in editable mode from /work/target, so whichever tree is copied into target/
is the code that gets imported in later runs.
"""
from __future__ import annotations

import configparser
import json
import re
import shlex
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    tomllib = None

from .sandbox import Mount, Sandbox

CANDIDATES = [(3, 8), (3, 9), (3, 10), (3, 11), (3, 12), (3, 13)]
DEFAULT_VERSION = (3, 11)
TEST_EXTRAS = ("test", "tests", "testing", "dev")
REQ_FILES = ("requirements.txt", "requirements-dev.txt", "requirements_dev.txt", "dev-requirements.txt",
             "requirements-test.txt", "requirements_test.txt", "test-requirements.txt", "requirements-tests.txt",
             "requirements/test.txt", "requirements/tests.txt", "requirements/dev.txt", "requirements/testing.txt",
             "tests/requirements.txt", "test/requirements.txt")


# ---------------------------------------------------------------- metadata
def _read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def project_metadata(tree: Path) -> Dict[str, object]:
    """requires-python, classifier versions, extras and project name from pyproject, setup.cfg or setup.py."""
    tree = Path(tree)
    meta: Dict[str, object] = {"requires_python": "", "classifier_versions": [], "extras": [], "name": ""}
    texts = []
    pp = tree / "pyproject.toml"
    if pp.is_file() and tomllib is not None:
        try:
            data = tomllib.loads(_read(pp))
            proj = data.get("project", {})
            meta["requires_python"] = proj.get("requires-python", "") or ""
            meta["extras"] = list((proj.get("optional-dependencies") or {}).keys())
            meta["name"] = proj.get("name", "") or ""
            texts.append("\n".join(proj.get("classifiers", []) or []))
            poetry = data.get("tool", {}).get("poetry", {})
            if poetry:
                meta["name"] = meta["name"] or poetry.get("name", "")
                py = (poetry.get("dependencies") or {}).get("python", "")
                if isinstance(py, str) and not meta["requires_python"]:
                    meta["requires_python"] = py.replace("^", ">=")
                meta["extras"] = list(meta["extras"]) + list((poetry.get("extras") or {}).keys())
                texts.append("\n".join(poetry.get("classifiers", []) or []))
        except Exception:  # noqa: BLE001 - malformed metadata must not stop the build
            pass
    cfg = tree / "setup.cfg"
    if cfg.is_file():
        cp = configparser.ConfigParser(interpolation=None)
        try:
            cp.read_string(_read(cfg))
            if not meta["requires_python"]:
                meta["requires_python"] = cp.get("options", "python_requires", fallback="").strip()
            if cp.has_section("options.extras_require"):
                meta["extras"] = list(meta["extras"]) + list(cp["options.extras_require"].keys())
            meta["name"] = meta["name"] or cp.get("metadata", "name", fallback="")
            texts.append(cp.get("metadata", "classifiers", fallback=""))
        except Exception:  # noqa: BLE001
            pass
    sp = tree / "setup.py"
    if sp.is_file():
        s = _read(sp)
        texts.append(s)
        if not meta["requires_python"]:
            m = re.search(r"python_requires\s*=\s*['\"]([^'\"]+)['\"]", s)
            if m:
                meta["requires_python"] = m.group(1)
        m = re.search(r"extras_require\s*=\s*\{(.*?)\}\s*[,)]", s, re.S)
        if m:
            meta["extras"] = list(meta["extras"]) + re.findall(r"['\"]([A-Za-z0-9_.-]+)['\"]\s*:", m.group(1))
        if not meta["name"]:
            m = re.search(r"\bname\s*=\s*['\"]([^'\"]+)['\"]", s)
            if m:
                meta["name"] = m.group(1)
    vers = set()
    for t in texts:
        for a, b in re.findall(r"Programming Language :: Python :: (\d)\.(\d+)", t):
            vers.add((int(a), int(b)))
    meta["classifier_versions"] = sorted(vers)
    meta["extras"] = sorted(set(meta["extras"]))
    return meta


def _vt(s: str) -> Tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", s)[:3])


def spec_allows(ver: Tuple[int, int], spec: str) -> bool:
    """Minimal PEP 440 specifier check on (major, minor), enough for requires-python strings."""
    spec = (spec or "").strip()
    if not spec:
        return True
    v = ver + (99,)           # a release late in the minor series
    for clause in [c.strip() for c in spec.split(",") if c.strip()]:
        m = re.match(r"(~=|==|!=|>=|<=|>|<)?\s*([0-9][0-9.*]*)", clause)
        if not m:
            continue
        op, raw = m.group(1) or "==", m.group(2)
        if raw.endswith(".*"):
            prefix = _vt(raw[:-2])
            hit = ver[:len(prefix)] == prefix[:len(ver)]
            if op == "==" and not hit:
                return False
            if op == "!=" and hit:
                return False
            continue
        target = _vt(raw)
        if op == "~=":
            lo = target
            hi = (target[0] + 1,) if len(target) <= 2 else (target[0], target[1] + 1)
            if not (v >= lo and v[:len(hi)] < hi):
                return False
        elif op == ">=" and not (v >= target):
            return False
        elif op == ">" and not (ver > target[:2] or (ver == target[:2] and len(target) > 2)):
            return False
        elif op == "<=" and not (ver <= target[:2]):
            return False
        elif op == "<" and not (ver < target[:2] if len(target) >= 2 else ver[0] < target[0]):
            return False
        elif op == "==" and ver != target[:2]:
            return False
        elif op == "!=" and len(target) == 2 and ver == target:
            return False
    return True


def detect_python(tree: Path) -> Tuple[str, str]:
    meta = project_metadata(tree)
    spec = str(meta["requires_python"])
    allowed = [v for v in CANDIDATES if spec_allows(v, spec)]
    cls = [tuple(v) for v in meta["classifier_versions"]]
    both = [v for v in allowed if v in cls]
    if both:
        v, why = max(both), "newest version both in the classifiers and in requires-python"
    elif allowed:
        under = [v for v in allowed if v <= DEFAULT_VERSION]
        v, why = (max(under), "newest allowed version up to 3.11") if under else (min(allowed), "oldest allowed")
    else:
        v, why = DEFAULT_VERSION, "no usable metadata: default 3.11"
    return f"{v[0]}.{v[1]}", f"{why} (requires-python {spec!r}, classifiers {[f'{a}.{b}' for a, b in cls]})"


def clean_constraints(text: str) -> str:
    """Keep pinned dependencies only: drop editable/local installs (they are the project itself)."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("-e") or s.startswith("--"):
            continue
        is_direct_url = "@" in s and "://" in s.split("@", 1)[1]
        if " @ file:" in s or s.startswith("file:") or is_direct_url:
            continue
        out.append(s)
    return "\n".join(out) + ("\n" if out else "")


# ---------------------------------------------------------------- build
def venv_ready(envdir: Path) -> bool:
    """True if envdir/.venv has a python, even when it is a symlink into a path that only exists in the
    container (/opt/uvpython/...), as it always is with the Docker backend."""
    py = Path(envdir) / ".venv" / "bin" / "python"
    return py.is_symlink() or py.exists()


def _keep_build_metadata(case) -> List[str]:
    """Legacy editable installs leave *.egg-info in the source tree. target/ is re-copied before every run,
    so copy that metadata into both trees or entry points and version lookups would vanish."""
    import shutil
    target, vuln, patched = case.p("target"), case.p("trees", "vulnerable"), case.p("trees", "patched")
    kept = []
    for d in list(target.glob("*.egg-info")) + list(target.glob("src/*.egg-info")):
        rel = d.relative_to(target)
        if (vuln / rel).exists():
            continue
        for tree in (vuln, patched):
            if tree.exists():
                shutil.copytree(d, tree / rel, dirs_exist_ok=True)
        kept.append(str(rel))
    return kept


def build_env(sbx: Sandbox, case, mounts_base: List[Mount], python: Optional[str] = None,
              constraints: Optional[str] = None, exclude_newer: Optional[str] = None,
              setup_script: Optional[str] = None, timeout_s: float = 2400.0) -> Dict[str, object]:
    """Build /work/env/.venv for the tree in trees/vulnerable.

    Without setup_script the tool installs the project (editable, with its test extras and requirement
    files). With setup_script, the user's own build recipe runs instead, one command per line, from
    /work/target with VIRTUAL_ENV, PATH and PIP_CONSTRAINT/UV_CONSTRAINT set; a failing line is logged
    and the next one runs, as a CI job with `continue-on-error` would.
    """
    tree = case.p("trees", "vulnerable")
    meta = project_metadata(tree)
    if python:
        version, why = python, "given by the user"
    else:
        version, why = detect_python(tree)
    envdir = case.p("env")
    for stale in ("has_pytest_timeout", "origin.json", "python_version.txt", "freeze.txt"):
        if (envdir / stale).exists():
            (envdir / stale).unlink()
    # always present, possibly empty: recipes may pass --constraint "$PIP_CONSTRAINT"
    (envdir / "constraints.txt").write_text(clean_constraints(constraints) if constraints else "", encoding="utf-8")
    extras = [e for e in TEST_EXTRAS if e in meta["extras"]]
    specs = ([f"/work/target[{','.join(extras)}]"] if extras else []) + ["/work/target"]
    reqs = [f"/work/target/{r}" for r in REQ_FILES if (tree / r).is_file()]
    common = "--python /work/env/.venv/bin/python"
    if constraints:
        common += " -c /work/env/constraints.txt -b /work/env/constraints.txt"
    if exclude_newer:
        common += f" --exclude-newer {shlex.quote(exclude_newer)}"
    head = f"""set -uo pipefail
export UV_PYTHON_INSTALL_DIR=/opt/uvpython UV_CACHE_DIR=/opt/uvcache UV_NO_PROGRESS=1 UV_LINK_MODE=copy
PY=/work/env/.venv/bin/python
rm -rf /work/env/.venv
uv venv --seed --python {shlex.quote(version)} /work/env/.venv || exit 10
export VIRTUAL_ENV=/work/env/.venv PATH=/work/env/.venv/bin:$PATH
"""
    head += "export PIP_CONSTRAINT=/work/env/constraints.txt UV_CONSTRAINT=/work/env/constraints.txt\n"
    head += "cd /work/target\n"
    if setup_script:
        body = """while IFS= read -r cmd || [ -n "$cmd" ]; do
  case "$cmd" in ''|'#'*) continue;; esac
  echo "[evigate] setup: $cmd"
  bash -c "$cmd" || echo "[evigate] warning: setup command failed (exit $?): $cmd"
done < /work/env/user_setup.txt
"""
    else:
        body = f"""ok=0
for spec in {' '.join(shlex.quote(s) for s in specs)}; do
  if uv pip install {common} -e "$spec"; then ok=1; echo "[evigate] installed $spec"; break; fi
done
[ "$ok" = 1 ] || exit 11
for r in {' '.join(shlex.quote(r) for r in reqs)}; do
  uv pip install {common} -r "$r" || echo "[evigate] warning: $r did not install"
done
# the project under test must be the tree in /work/target, never a copy from an index
uv pip install --python $PY --no-deps -e /work/target || exit 13
"""
    tail = f"""$PY -c "import pytest" 2>/dev/null || uv pip install --python $PY pytest || exit 12
$PY -c "import pytest_timeout" 2>/dev/null || uv pip install --python $PY pytest-timeout || echo "[evigate] warning: pytest-timeout did not install"
$PY -c "import pytest_timeout" 2>/dev/null && touch /work/env/has_pytest_timeout
cd /tmp    # read the installed metadata, not an egg-info left in the source tree
$PY - > /work/env/origin.json <<'PYEOF'
import json
out = {{"name": {json.dumps(str(meta["name"]))}}}
try:
    import importlib.metadata as md
    out["direct_url"] = json.loads(md.distribution(out["name"]).read_text("direct_url.json") or "null")
except Exception as e:
    out["error"] = repr(e)
print(json.dumps(out))
PYEOF
uv pip freeze --python $PY > /work/env/freeze.txt
$PY -V > /work/env/python_version.txt 2>&1
exit 0
"""
    script = head + body + tail
    case.select_tree("vulnerable")
    mounts = list(mounts_base) + [Mount(case.p("target"), "/work/target", ro=False),
                                  Mount(envdir, "/work/env", ro=False)]
    (envdir / "setup.sh").write_text(sbx.materialize(script, mounts), encoding="utf-8")
    if setup_script:
        (envdir / "user_setup.txt").write_text(sbx.materialize(setup_script, mounts), encoding="utf-8")
    res = sbx.run(["bash", "/work/env/setup.sh"], mounts, network="setup", timeout_s=timeout_s,
                  log_path=case.p("logs", "env_setup.log"), env={"UV_PYTHON_INSTALL_DIR": "/opt/uvpython",
                                                                    "UV_CACHE_DIR": "/opt/uvcache"})
    # The venv's python is a symlink to an interpreter that exists only inside the container
    # (/opt/uvpython): check the link itself, not its target.
    ok = res.rc == 0 and not res.timed_out and venv_ready(envdir)
    log_text = _read(case.p("logs", "env_setup.log"))
    failed_lines = [l.split("):", 1)[-1].strip()[:200] for l in log_text.splitlines()
                    if "[evigate] warning: setup command failed" in l]
    kept = _keep_build_metadata(case) if ok else []
    try:
        origin = json.loads(_read(envdir / "origin.json") or "{}")
    except json.JSONDecodeError:
        origin = {}
    du = origin.get("direct_url") or {}
    expected = sbx.materialize("file:///work/target", mounts)
    info = {
        "ok": ok, "rc": res.rc, "timed_out": res.timed_out, "seconds": round(res.seconds, 1),
        "python_requested": version, "python_reason": why,
        "python_actual": _read(envdir / "python_version.txt").strip(),
        "recipe": "user setup script" if setup_script else "automatic",
        "extras": extras if not setup_script else None,
        "requirement_files": reqs if not setup_script else None,
        "constraints": bool(constraints), "exclude_newer": exclude_newer, "project_name": meta["name"],
        "installed_from_tree": bool(du) and str(du.get("url", "")).rstrip("/") == expected.rstrip("/"),
        "installed_editable": bool((du.get("dir_info") or {}).get("editable")),
        "pytest_timeout": (envdir / "has_pytest_timeout").exists(),
        "recipe_failed_lines": failed_lines,
        "constraints_lines": len([l for l in _read(envdir / "constraints.txt").splitlines() if l.strip()]),
        "build_metadata_kept": kept,
    }
    (envdir / "env.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    return info
