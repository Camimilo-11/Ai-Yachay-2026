"""The claim rule. It is deterministic and reads only execution results.

The system says "verified" only when it has executable evidence for every part of the claim:
  1. the patch applies;
  2. the environment was built and the project's own tests ran (at least `min_baseline_pass` passed on the
     original code);
  3. at least one attack test reproduced the vulnerability on the original code (ATTACK in every repetition);
  4. every reproduced attack test passes on the patched code (PASS in every repetition);
  5. no project test that passed on the original code fails on the patched code (after a flake re-check);
  6. the white-box attacker found no test that still attacks the patched code.
Anything else is not a repair claim, and the status says why.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional

STATUS_ORDER = ["patch_does_not_apply", "env_failed", "no_functional_evidence", "not_reproduced",
                "not_blocked", "inconclusive", "regression", "bypass", "introduced_weakness", "verified"]


@dataclass
class Verdict:
    claim: int
    status: str
    reasons: List[str] = field(default_factory=list)
    counts: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def reproduced_tests(poc_vuln: Dict[str, dict]) -> List[str]:
    return sorted(k for k, v in poc_vuln.items() if v["outcome"] == "ATTACK" and not k.endswith("::<collection>"))


def decide(patch_applies: bool, env_ok: bool, baseline_vuln: Optional[Dict[str, dict]],
           poc_vuln: Optional[Dict[str, dict]], poc_patched: Optional[Dict[str, dict]],
           regressions: Optional[List[str]], bypass_patched: Optional[Dict[str, dict]],
           bypass_vuln: Optional[Dict[str, dict]], min_baseline_pass: int = 1) -> Verdict:
    counts: Dict[str, int] = {}
    if not patch_applies:
        return Verdict(0, "patch_does_not_apply", ["the patch does not apply to the code"], counts)
    if not env_ok:
        return Verdict(0, "env_failed", ["the project's environment could not be built: no evidence possible"], counts)
    passing = [k for k, v in (baseline_vuln or {}).items() if v["outcome"] == "PASS"]
    counts["baseline_passing"] = len(passing)
    if len(passing) < min_baseline_pass:
        return Verdict(0, "no_functional_evidence",
                       [f"only {len(passing)} project tests pass on the original code (minimum {min_baseline_pass})"],
                       counts)
    repro = reproduced_tests(poc_vuln or {})
    counts["poc_written"] = len([k for k in (poc_vuln or {}) if not k.endswith("::<collection>")])
    counts["poc_reproduced"] = len(repro)
    if not repro:
        return Verdict(0, "not_reproduced",
                       ["no attack test reproduced the vulnerability on the original code: nothing to show the patch fixes"],
                       counts)
    still = [k for k in repro if (poc_patched or {}).get(k, {}).get("outcome") == "ATTACK"]
    unclear = [k for k in repro if (poc_patched or {}).get(k, {}).get("outcome") not in ("PASS", "ATTACK")]
    counts["poc_blocked"] = len([k for k in repro if (poc_patched or {}).get(k, {}).get("outcome") == "PASS"])
    if still:
        return Verdict(0, "not_blocked", [f"the attack still works on the patched code: {k}" for k in still], counts)
    if unclear:
        return Verdict(0, "inconclusive",
                       [f"{k}: {(poc_patched or {}).get(k, {}).get('outcome', 'NOT_RUN')} on the patched code"
                        for k in unclear], counts)
    counts["regressions"] = len(regressions or [])
    if regressions:
        return Verdict(0, "regression", [f"project test fails only with the patch: {k}" for k in regressions[:20]], counts)
    attacks = [k for k, v in (bypass_patched or {}).items()
               if v["outcome"] == "ATTACK" and not k.endswith("::<collection>")]
    counts["bypass_tests"] = len([k for k in (bypass_patched or {}) if not k.endswith("::<collection>")])
    counts["bypass_attacks"] = len(attacks)
    if attacks:
        real = [k for k in attacks if (bypass_vuln or {}).get(k, {}).get("outcome") == "ATTACK"]
        if real:
            return Verdict(0, "bypass", [f"the white-box attacker got around the patch: {k}" for k in real], counts)
        return Verdict(0, "introduced_weakness",
                       [f"an attack works on the patched code but not on the original: {k}" for k in attacks], counts)
    return Verdict(1, "verified", [
        f"{len(repro)} attack test(s) reproduced the vulnerability on the original code and all pass with the patch",
        f"{len(passing)} project tests that passed before still pass",
        "the white-box attacker found no way around the patch"], counts)
