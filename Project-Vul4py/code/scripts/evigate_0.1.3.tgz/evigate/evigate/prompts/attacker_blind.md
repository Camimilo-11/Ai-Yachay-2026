# Task: write executable attack tests (proofs of concept)

The code in /work/target is a Python project reported to contain a security vulnerability. /work/target is read-only. Write your files ONLY in /work/poc.

## The report

{report}

## Scope: the reported weakness, nothing else

Your tests must attack the weakness the report describes. When the report gives locations, they show where the maintainers changed the code to fix it: read those lines first and work out which weakness lives there and which public entry points reach it. Lines that only change a version string or documentation are not the weakness.

If you notice a different weakness somewhere else, mention it in your final summary, but do not write tests for it: a test for another weakness is not evidence about this report, and a fix for this report is not expected to stop it.

## What to produce

1. Test files `/work/poc/test_attack_*.py` (pytest). Each test states the SAFE behaviour of the code, so it FAILS on this vulnerable code because the attack works:
   - one primary test for the reported attack;
   - up to four variants that a complete fix must also stop: other public entry points that reach the same weak code, other encodings or formats of the payload, other sizes or nesting depths. Use the weakness catalogue (below) to think of variants.
2. `/work/poc/ATTACKS.json`: a list with one object per test you keep:
   `{{"test": "<file>::<function>", "kind": "primary" or "variant", "cwe": "CWE-...", "entry_point": "<public function, class or command>", "weak_code": "<file:line of the weak code the attack reaches>", "attack": "<one sentence>", "observable": "<what the test checks>", "why_this_is_the_reported_weakness": "<one sentence>"}}`

## Rules for the tests

- Check the attack's observable EFFECT, not how one particular fix would look. Never assert a specific exception class, error message, return value or new function or parameter that only some fix would introduce. A correct fix may reject the input with any exception, sanitize it or bound it, and your test must pass for all of those.
  - Good: "the canary file was not created"; "parsing the bomb finishes in under 5 s and under 512 MB, or raises"; "the forged token is not accepted"; "the payload does not come back unescaped".
  - Bad: "raises LimitExceeded"; "returns None"; "calls validate_url()".
- Use the helpers in the module `evigate_poc` (already importable):
  - `run_isolated(fn, *args, timeout_s=..., memory_mb=..., **kwargs) -> Outcome` for anything that may hang, exhaust memory or crash. A test that may hang or crash MUST go through it.
  - `assert_bounded(outcome, what="...", max_seconds=...)` turns resource exhaustion into an assertion failure; a clean exception counts as safe.
  - `Canary()` with `.shell_payload`, `.python_payload` and `.assert_not_triggered()` for command, code or path injection.
  - `assert_not_reflected(output, payload)` for injection into output.
- Reach the weak code through the project's public API or documented entry points, the way an attacker's input would, with the library's default settings or settings that a normal caller of the affected feature would use. Do not monkeypatch the code under test.
- No network. Keep each test under 30 s.
- Do not modify anything outside /work/poc.

## How to check your tests

Run `evigate-run /work/poc`. It runs pytest against /work/target and prints one outcome per test:

- `ATTACK`: the safe-behaviour assertion failed, so the attack works. This is what you want on this code.
- `PASS`: the attack did not work; the test does not reproduce the vulnerability.
- `INVALID`: the test errored for another reason (import error, wrong API). Fix it or remove it.
- `TIMEOUT` or `CRASH`: the test itself hung or crashed. Wrap the risky call in `run_isolated`.

Iterate until every test you keep shows ATTACK, and delete the ones that do not. Only ATTACK tests count. If after a serious effort you cannot reproduce the vulnerability, leave /work/poc without test files and say so: an honest "not reproduced" is better than a test that checks something else.

## Tools

- The project's Python: `/work/env/.venv/bin/python`
- Offline weakness catalogue (CWE and CAPEC): `evigate-kb search "<words>"` and `evigate-kb show CWE-<id>`

When you are done, reply with a short summary: the CWE, the entry points, and which tests reproduce.
