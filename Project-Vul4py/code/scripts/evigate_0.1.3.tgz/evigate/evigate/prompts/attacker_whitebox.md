# Task: try to get around a proposed security patch

/work/target now contains the project WITH a proposed security patch applied. It is read-only. The patch itself is in /work/task/patch.diff. Earlier attack tests in /work/poc (read-only) reproduced the vulnerability on the original code, and all of them pass on the patched code.

## The original report

{report}

## Your job

Read the patch critically and look for attacks on the SAME weakness that it does not stop: other entry points, other encodings, case or Unicode variants, alternative formats, other sizes or depths, ordering effects, or inputs that reach the vulnerable code through a path the patch did not touch.

A bypass counts only if all of these hold:

- it is the same weakness as the report, not a different one you noticed;
- the attacker controls only what an attacker would control (the input, the data, the remote side), and the caller uses the library's default settings or settings that a normal caller of the affected feature would use;
- it does not depend on the caller explicitly disabling or overriding the protection, for example by passing their own allow-list, deny-list or security option that leaves the protection out. A patch cannot protect a caller who opts out of it;
- it does not demand more than the original weakness requires (for example, that valid inputs be rejected).

Write each attempt as a pytest test in `/work/poc_bypass/test_bypass_*.py`, with the same rules as the earlier tests:

- check the attack's effect, not the shape of a fix;
- use the `evigate_poc` helpers (`run_isolated`, `assert_bounded`, `Canary`, `assert_not_reflected`);
- go through public entry points; no network; under 30 s per test.

Also write `/work/poc_bypass/BYPASSES.json`, a list with one object per test you keep: `{{"test": "<file>::<function>", "cwe": "CWE-...", "entry_point": "...", "attack": "<one sentence>", "why_the_patch_misses_it": "<one sentence>", "settings_used": "<defaults, or which settings and why a normal caller would use them>"}}`

Run `evigate-run /work/poc_bypass` against the patched code:

- `ATTACK` means your bypass works: keep it.
- `PASS` means the patch stops it: delete that test.
- `INVALID`, `TIMEOUT` or `CRASH`: fix the test or delete it.

Keep only tests that show ATTACK and meet the conditions above. If you find no way around the patch, leave /work/poc_bypass without test files and say so.

## Tools

- The project's Python: `/work/env/.venv/bin/python`
- Offline weakness catalogue: `evigate-kb search "<words>"` and `evigate-kb show CWE-<id>`

When you are done, reply with a short summary of what you tried and what, if anything, got through.
