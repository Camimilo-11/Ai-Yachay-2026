"""Deterministic test runner: no model is involved in any verdict that comes out of here.

Each test gets one outcome per tree:
  PASS     the test passed (for a PoC: the attack did not work)
  ATTACK   the test failed on an assertion (for a PoC: the attack's effect happened)
  INVALID  the test errored for another reason (import error, wrong API, broken fixture, collection error)
  TIMEOUT  the test did not finish within the run's time limit
  CRASH    the test process died while running it (segfault, out-of-memory kill)
  SKIP     the test was skipped
  NOT_RUN  the test was never reached
Repeated runs are combined: an outcome counts only if every repetition agrees; otherwise it is FLAKY.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from .sandbox import Mount, Sandbox

POC_HELPERS = "/opt/evigate/evigate/poclib"
PY = "/work/env/.venv/bin/python"


# ---------------------------------------------------------------- parsing
def parse_results(jsonl: Path, timed_out: bool) -> Dict[str, dict]:
    events = []
    if Path(jsonl).exists():
        for line in Path(jsonl).read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    res: Dict[str, dict] = {}
    finished = False
    for e in events:
        kind = e.get("event")
        if kind == "start":
            res.setdefault(e["nodeid"], {"phases": {}})
        elif kind == "report":
            res.setdefault(e["nodeid"], {"phases": {}})["phases"][e["when"]] = e
        elif kind == "collect_error":
            res[f"{e['nodeid']}::<collection>"] = {"outcome": "INVALID",
                                                   "detail": "collection error: " + e.get("message", "")[-300:]}
        elif kind == "session_finish":
            finished = True
    out: Dict[str, dict] = {}
    for nodeid, r in res.items():
        if "outcome" in r:
            out[nodeid] = {"outcome": r["outcome"], "detail": r["detail"]}
            continue
        ph = r["phases"]
        setup, call = ph.get("setup"), ph.get("call")
        if setup and setup["outcome"] == "failed":
            o, d = "INVALID", f"setup error {setup.get('exc_type')}: {setup.get('message', '')[:200]}"
        elif setup and setup["outcome"] == "skipped":
            o, d = "SKIP", setup.get("message", "")[:200]
        elif call is None:
            o, d = ("TIMEOUT", "killed by the run time limit") if timed_out and not finished else \
                   ("CRASH", "the test process died while running this test")
        elif call["outcome"] == "passed":
            o, d = "PASS", ""
        elif call["outcome"] == "skipped":
            o, d = "SKIP", call.get("message", "")[:200]
        else:
            msg = call.get("message", "") or ""
            if call.get("exc_type") == "Failed" and "Timeout" in msg:
                o, d = "TIMEOUT", msg[:200]
            elif call.get("is_assert"):
                o, d = "ATTACK", msg[:300]
            else:
                o, d = "INVALID", f"{call.get('exc_type')}: {msg[:250]}"
        out[nodeid] = {"outcome": o, "detail": d, "seconds": (call or setup or {}).get("duration")}
    return out


def combine(runs: Sequence[Dict[str, dict]]) -> Dict[str, dict]:
    ids = []
    for r in runs:
        for k in r:
            if k not in ids:
                ids.append(k)
    out = {}
    for k in ids:
        outs = [r.get(k, {"outcome": "NOT_RUN", "detail": ""}) for r in runs]
        kinds = {o["outcome"] for o in outs}
        if len(kinds) == 1:
            out[k] = dict(outs[0], runs=len(outs))
        else:
            out[k] = {"outcome": "FLAKY", "detail": " / ".join(o["outcome"] for o in outs), "runs": len(outs)}
    return out


# ---------------------------------------------------------------- official runs (through the sandbox)
def pytest_argv(test_args: Sequence[str], rootdir: str, clear_addopts: bool,
                extra_args: Sequence[str] = (), per_test_timeout: Optional[int] = None) -> List[str]:
    argv = [PY, "-m", "pytest", "-p", "evigate_pytest_plugin", "-p", "no:cacheprovider", "-q",
            "--continue-on-collection-errors", "--rootdir", rootdir]
    if clear_addopts:
        argv += ["-o", "addopts="]
    if per_test_timeout:
        argv += [f"--timeout={int(per_test_timeout)}"]
    return argv + list(extra_args) + list(test_args)


def tree_pythonpath(case, tree: str) -> str:
    """PoC helpers first, then the tree under test, so the code in /work/target is what gets imported
    even when a build recipe installed a copy into site-packages."""
    parts = [POC_HELPERS, "/work/target"]
    if case.p("trees", tree, "src").is_dir():
        parts.append("/work/target/src")
    return ":".join(parts)


def run_tests(sbx: Sandbox, case, mounts_base: List[Mount], tree: str, test_args: Sequence[str],
              label: str, rootdir: str, extra_mounts: Sequence[Mount] = (), target_ro: bool = True,
              timeout_s: float = 600.0, repeat: int = 1, clear_addopts: bool = True,
              max_passes: int = 4, extra_args: Sequence[str] = (),
              per_test_timeout: Optional[int] = None) -> Dict[str, dict]:
    """Run tests against trees/<tree> (copied into target/) and return one combined outcome per test."""
    all_runs = []
    for rep in range(1, repeat + 1):
        case.select_tree(tree)
        merged: Dict[str, dict] = {}
        pending: Optional[List[str]] = None
        for n in range(1, max_passes + 1):
            tag = f"{label}.r{rep}.p{n}"
            results_file = case.p("results", f"{tag}.jsonl")
            if results_file.exists():
                results_file.unlink()
            mounts = list(mounts_base) + [
                Mount(case.p("target"), "/work/target", ro=target_ro),
                Mount(case.p("env"), "/work/env", ro=True),
                Mount(case.p("results"), "/work/results", ro=False),
                *extra_mounts]
            args = list(test_args) if pending is None else pending
            env = {"PYTHONPATH": tree_pythonpath(case, tree), "EVIGATE_RESULTS": f"/work/results/{tag}.jsonl",
                   "PYTHONHASHSEED": "0"}
            res = sbx.run(pytest_argv(args, rootdir, clear_addopts, extra_args, per_test_timeout), mounts,
                          network="none", env=env,
                          workdir=rootdir, timeout_s=timeout_s, log_path=case.p("logs", f"{label}.log"))
            parsed = parse_results(results_file, res.timed_out)
            merged.update(parsed)
            ended_cleanly = _session_finished(results_file)
            if ended_cleanly or not parsed:
                break
            # The process died or was killed: collect the remaining test ids and run them in a new process.
            remaining = _remaining(sbx, case, mounts, list(extra_args) + list(args), rootdir, merged,
                                   clear_addopts, tree_pythonpath(case, tree))
            if not remaining:
                break
            pending = remaining
        all_runs.append(merged)
        case.write_json(f"results/{label}.r{rep}.json", merged)
    combined = combine(all_runs)
    case.write_json(f"results/{label}.json", combined)
    return combined


def _session_finished(results_file: Path) -> bool:
    if not results_file.exists():
        return False
    return any('"session_finish"' in line for line in results_file.read_text(errors="replace").splitlines())


def _remaining(sbx, case, mounts, args, rootdir, done: Dict[str, dict], clear_addopts,
               pythonpath: str = POC_HELPERS) -> List[str]:
    listing = case.p("results", "collect_only.txt")
    if listing.exists():
        listing.unlink()
    argv = [PY, "-m", "pytest", "--collect-only", "-q", "-p", "no:cacheprovider", "--rootdir", rootdir]
    if clear_addopts:
        argv += ["-o", "addopts="]
    sbx.run(argv + list(args), mounts, network="none", env={"PYTHONPATH": pythonpath}, workdir=rootdir,
            timeout_s=300, log_path=listing)
    ids = []
    for line in listing.read_text(errors="replace").splitlines():
        s = line.strip()
        if "::" in s and not s.startswith(("$", "[", "=")) and " " not in s:
            ids.append(s)
    return [i for i in ids if i not in done]


# ---------------------------------------------------------------- agent-facing run (inside the sandbox)
def run_here(test_paths: Sequence[str], target: str = "/work/target", python: str = PY,
             timeout_s: float = 300.0) -> Dict[str, dict]:
    """Used by `evigate run` inside the agent's container: runs the PoCs right here and prints outcomes."""
    results = Path(os.environ.get("TMPDIR", "/tmp")) / f"evigate_run_{os.getpid()}.jsonl"
    if results.exists():
        results.unlink()
    rootdir = str(Path(test_paths[0]).resolve().parent if Path(test_paths[0]).is_file() else Path(test_paths[0]).resolve())
    pp = [os.environ.get("EVIGATE_POCLIB", POC_HELPERS), target]
    if Path(target, "src").is_dir():
        pp.append(str(Path(target, "src")))
    env = dict(os.environ, PYTHONPATH=":".join(pp),
               EVIGATE_RESULTS=str(results), PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    argv = [python, "-m", "pytest", "-p", "evigate_pytest_plugin", "-p", "no:cacheprovider", "-q",
            "--continue-on-collection-errors", "--rootdir", rootdir, "-o", "addopts="]
    if Path(python).parent.parent.parent.joinpath("has_pytest_timeout").exists():   # /work/env/has_pytest_timeout
        argv.append("--timeout=120")
    argv += list(test_paths)
    timed_out = False
    try:
        cp = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=timeout_s, cwd=rootdir)
        tail = (cp.stdout + cp.stderr)[-3000:]
    except subprocess.TimeoutExpired:
        timed_out = True
        tail = f"[evigate] the run exceeded {timeout_s} s and was stopped"
    out = parse_results(results, timed_out)
    print(tail, file=sys.stderr)
    return out


def format_table(results: Dict[str, dict]) -> str:
    lines = [f"{'OUTCOME':8}  TEST  (detail)"]
    for k, v in sorted(results.items()):
        det = (v.get("detail") or "").replace("\n", " ")
        lines.append(f"{v['outcome']:8}  {k}" + (f"  ({det[:160]})" if det else ""))
    return "\n".join(lines)
