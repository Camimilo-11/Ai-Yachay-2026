"""Where every command runs.

Three network modes, chosen per command:
  none   no network at all: PoC and project test runs.
  setup  normal egress: only the environment build (uv downloading Python and dependencies); no agent runs here.
  agent  an internal Docker network whose only way out is an allowlist proxy that lets the agent CLI reach
         its model API and nothing else, so the agent's own commands cannot download fixes or leak data.

Every container gets memory, CPU and process limits, a read-only root filesystem, no capabilities and only
the directories it needs, mounted read-only unless the step must write there.

The "local" backend runs the same commands directly on this machine with paths translated. It gives no
isolation and exists only for development and the tool's own tests.
"""
from __future__ import annotations

import os
import shlex
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence


@dataclass
class Mount:
    host: Path
    target: str
    ro: bool = True


@dataclass
class Limits:
    memory_mb: int = 3072
    cpus: float = 1.5
    pids: int = 512
    tmp_mb: int = 2048


@dataclass
class RunResult:
    rc: int
    timed_out: bool
    seconds: float
    log: Optional[Path]
    argv: List[str] = field(default_factory=list)


@dataclass
class DockerSettings:
    image: str = "evigate-sandbox:0.1"
    agent_network: str = "evigate_int"
    proxy_url: str = "http://evigate-proxy:3128"
    setup_network: str = "bridge"


class Sandbox:
    def __init__(self, backend: str = "docker", limits: Optional[Limits] = None,
                 docker: Optional[DockerSettings] = None) -> None:
        if backend not in ("docker", "local"):
            raise ValueError(f"unknown backend {backend!r}")
        self.backend = backend
        self.limits = limits or Limits()
        self.docker = docker or DockerSettings()
        if backend == "local":
            print("[evigate] WARNING: local backend, no isolation (development only)", file=sys.stderr)

    # ------------------------------------------------------------------ public
    def run(self, argv: Sequence[str], mounts: Sequence[Mount], network: str = "none",
            env: Optional[Dict[str, str]] = None, passthrough: Iterable[str] = (),
            workdir: str = "/work", timeout_s: float = 600.0, log_path: Optional[Path] = None,
            stdin_text: Optional[str] = None, limits: Optional[Limits] = None) -> RunResult:
        if network not in ("none", "setup", "agent"):
            raise ValueError(f"unknown network mode {network!r}")
        env = dict(env or {})
        lim = limits or self.limits
        if self.backend == "docker":
            full, name = self._docker_argv(argv, mounts, network, env, passthrough, workdir, stdin_text is not None, lim)
            return self._exec(full, None, timeout_s, log_path, stdin_text, kill_name=name)
        local_argv, local_env, local_cwd = self._local_translate(argv, mounts, env, workdir, passthrough)
        return self._exec(local_argv, local_env, timeout_s, log_path, stdin_text, cwd=local_cwd)

    def materialize(self, text: str, mounts: Sequence[Mount]) -> str:
        """Text that names container paths (a script, a prompt), as the running backend must see it."""
        return text if self.backend == "docker" else self._translator(mounts)(text)

    # ------------------------------------------------------------------ docker
    def _docker_argv(self, argv, mounts, network, env, passthrough, workdir, interactive, lim):
        name = "evigate_" + uuid.uuid4().hex[:12]
        d = self.docker
        cmd = ["docker", "run", "--rm", "--name", name,
               "--user", f"{os.getuid()}:{os.getgid()}",
               "--read-only",
               "--tmpfs", f"/tmp:rw,exec,nosuid,mode=1777,size={lim.tmp_mb}m",
               "--tmpfs", "/home/agent:rw,exec,nosuid,mode=1777,size=1024m",
               "--memory", f"{lim.memory_mb}m", "--memory-swap", f"{lim.memory_mb}m",
               "--pids-limit", str(lim.pids), "--cpus", str(lim.cpus),
               "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
               "-e", "HOME=/home/agent", "-e", "PYTHONDONTWRITEBYTECODE=1"]
        if interactive:
            cmd.append("-i")
        if network == "none":
            cmd += ["--network", "none"]
        elif network == "setup":
            cmd += ["--network", d.setup_network]
        else:
            cmd += ["--network", d.agent_network]
            for k in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"):
                cmd += ["-e", f"{k}={d.proxy_url}"]
            cmd += ["-e", "NO_PROXY=localhost,127.0.0.1", "-e", "no_proxy=localhost,127.0.0.1"]
        for k, v in env.items():
            cmd += ["-e", f"{k}={v}"]
        for k in passthrough:          # value taken from this process's environment, never written to disk
            if k in os.environ:
                cmd += ["-e", k]
        for m in mounts:
            host = Path(m.host).resolve()
            cmd += ["-v", f"{host}:{m.target}:{'ro' if m.ro else 'rw'}"]
        cmd += ["-w", workdir, d.image, *argv]
        return cmd, name

    # ------------------------------------------------------------------ local
    @staticmethod
    def _translator(mounts):
        pairs = sorted(((m.target.rstrip("/"), str(Path(m.host).resolve())) for m in mounts),
                       key=lambda p: len(p[0]), reverse=True)

        def tr(s: str) -> str:
            for tgt, host in pairs:
                s = s.replace(tgt, host)
            return s
        return tr

    def _local_translate(self, argv, mounts, env, workdir, passthrough):
        tr = self._translator(mounts)
        keep = ("PATH", "LANG", "LC_ALL", "TERM", "UV_CACHE_DIR", "UV_PYTHON_INSTALL_DIR", "UV_NATIVE_TLS",
                "UV_SYSTEM_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE",
                "NODE_EXTRA_CA_CERTS", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy",
                "no_proxy")
        base = {k: v for k, v in os.environ.items() if k in keep}
        for k in passthrough:
            if k in os.environ:
                base[k] = os.environ[k]
        home = Path(os.environ.get("EVIGATE_LOCAL_HOME", "/tmp/evigate_local_home"))
        home.mkdir(parents=True, exist_ok=True)
        base["HOME"] = str(home)
        base["PYTHONDONTWRITEBYTECODE"] = "1"
        base.update({k: tr(v) for k, v in env.items()})
        cwd = tr(workdir)
        if not Path(cwd).is_dir():          # a container-only directory such as /work itself
            cwd = str(home)
        return [tr(a) for a in argv], base, cwd

    # ------------------------------------------------------------------ common
    def _exec(self, argv, env, timeout_s, log_path, stdin_text, cwd=None, kill_name=None) -> RunResult:
        t0 = time.monotonic()
        log_f = open(log_path, "a", encoding="utf-8") if log_path else subprocess.DEVNULL
        try:
            if log_path:
                log_f.write(f"\n$ {shlex.join(argv)}\n")
                log_f.flush()
            proc = subprocess.Popen(argv, stdout=log_f, stderr=subprocess.STDOUT,
                                    stdin=subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL,
                                    env=env, cwd=cwd, text=True, start_new_session=True)
            timed_out = False
            try:
                proc.communicate(input=stdin_text, timeout=timeout_s)
            except subprocess.TimeoutExpired:
                timed_out = True
                if kill_name:
                    subprocess.run(["docker", "kill", kill_name], capture_output=True)
                try:
                    os.killpg(proc.pid, 9)
                except (ProcessLookupError, PermissionError):
                    pass
                proc.wait()
            rc = proc.returncode if proc.returncode is not None else -9
            if log_path:
                log_f.write(f"[exit {rc}{' TIMEOUT' if timed_out else ''} after {time.monotonic() - t0:.1f} s]\n")
            return RunResult(rc, timed_out, time.monotonic() - t0, log_path, list(argv))
        finally:
            if log_path:
                log_f.close()
