"""Verify mode: given any repository, a vulnerability report and a patch, decide whether the patch can be
claimed as a verified repair, and keep the evidence.

Nothing in this module knows about any benchmark or dataset.
"""
from __future__ import annotations

import datetime as dt
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from . import envbuild, evidence, rule, runner
from .sandbox import Mount, Sandbox
from .workspace import prepare_case, sha256_file, sha256_text

PROMPTS = Path(__file__).resolve().parent / "prompts"
VERSION = "0.1.3"


@dataclass
class Settings:
    python: Optional[str] = None
    constraints: Optional[str] = None
    exclude_newer: Optional[str] = None
    setup_script: Optional[str] = None         # the user's own build recipe (one command per line)
    test_args: tuple = ()                      # extra pytest arguments for the project's own tests
    per_test_timeout_s: int = 180              # used when pytest-timeout is available
    env_timeout_s: float = 2400.0
    baseline_timeout_s: float = 1800.0
    poc_timeout_s: float = 600.0
    poc_repeats: int = 2
    min_baseline_pass: int = 1
    limit_wait_s: float = 600.0
    limit_max_wait_s: float = 5.5 * 3600
    cache_dir: Path = field(default_factory=lambda: Path.home() / ".cache" / "evigate")


class AuthFailure(RuntimeError):
    pass


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _report_for_agents(report: str, hint: Optional[str]) -> str:
    text = report.strip()
    if hint and hint.strip():
        text += "\n\nLocation hint (where to look, not how to fix):\n" + hint.strip()
    return text


def _run_agent(agent, sbx: Sandbox, mounts, system_text: str, task_text: str, transcript: Path,
               st: Settings) -> dict:
    waited = 0.0
    attempts = []
    while True:
        res = agent.run(sbx, mounts, sbx.materialize(system_text, mounts), sbx.materialize(task_text, mounts),
                        transcript)
        attempts.append({"status": res.status, "seconds": round(res.seconds, 1)})
        if res.status == "auth":
            raise AuthFailure(f"{agent.name}: authentication failed; check the token or login")
        if res.status != "limit" or waited >= st.limit_max_wait_s:
            break
        time.sleep(st.limit_wait_s)
        waited += st.limit_wait_s
    return {"agent": agent.name, "status": res.status, "seconds": round(res.seconds, 1), "turns": res.turns,
            "usage": res.usage, "model_reported": res.model_reported, "attempts": attempts,
            "final_text": res.final_text, "transcript": Path(transcript).name,
            "transcript_sha256": sha256_file(Path(transcript)) if Path(transcript).exists() else ""}


def verify(repo: Path, report: str, patch: str, out_dir: Path, attacker, sbx: Sandbox,
           hint: Optional[str] = None, st: Optional[Settings] = None) -> dict:
    st = st or Settings()
    t_start = time.monotonic()
    state: Dict[str, object] = {"tool": {"name": "evigate", "version": VERSION, "source_sha256": evidence.tool_digest()},
                                "mode": "verify", "started_at_utc": _now(), "backend": sbx.backend,
                                "attacker": attacker.name}
    case, info = prepare_case(out_dir, repo, report, hint, patch)
    state["inputs"] = {"report_sha256": sha256_text(report), "hint_sha256": sha256_text(hint or ""),
                       "patch_sha256": info.get("patch_sha256"), "repo_manifest_sha256": info["vulnerable_manifest"],
                       "patched_manifest_sha256": info.get("patched_manifest"), "patch_files": info.get("patch_files")}
    state["prepare"] = {k: v for k, v in info.items() if k.startswith(("copy", "patch_applies", "patch_apply"))}
    steps: Dict[str, object] = {}
    state["steps"] = steps

    def finish(v: rule.Verdict) -> dict:
        state["verdict"] = v.to_dict()
        state["finished_at_utc"] = _now()
        state["seconds"] = round(time.monotonic() - t_start, 1)
        case.write_json("verdict.json", state)
        evidence.write_manifest(case.root)
        return state

    if not info.get("patch_applies"):
        return finish(rule.decide(False, False, None, None, None, None, None, None))

    cache = Path(st.cache_dir)
    (cache / "uvpython").mkdir(parents=True, exist_ok=True)
    (cache / "uvcache").mkdir(parents=True, exist_ok=True)
    pkg = Mount(evidence.PACKAGE_ROOT, "/opt/evigate", ro=True)
    setup_mounts = [pkg, Mount(cache / "uvpython", "/opt/uvpython", ro=False),
                    Mount(cache / "uvcache", "/opt/uvcache", ro=False)]
    run_mounts = [pkg, Mount(cache / "uvpython", "/opt/uvpython", ro=True)]

    # 1. environment
    t = time.monotonic()
    env = envbuild.build_env(sbx, case, setup_mounts, python=st.python, constraints=st.constraints,
                             exclude_newer=st.exclude_newer, setup_script=st.setup_script,
                             timeout_s=st.env_timeout_s)
    steps["env"] = dict(env, step_seconds=round(time.monotonic() - t, 1))
    if not env["ok"]:
        return finish(rule.decide(True, False, None, None, None, None, None, None))

    # 2. project tests on the original code (functional baseline)
    t = time.monotonic()
    ptt = st.per_test_timeout_s if env.get("pytest_timeout") else None
    targs = list(st.test_args)
    clear = False
    base_v = runner.run_tests(sbx, case, run_mounts, "vulnerable", [], "baseline_vulnerable", "/work/target",
                              target_ro=False, timeout_s=st.baseline_timeout_s, clear_addopts=False,
                              extra_args=targs, per_test_timeout=ptt)
    if not any(v["outcome"] in ("PASS", "ATTACK") for v in base_v.values()):
        clear = True               # the project's pytest options may need plugins that are missing
        base_v = runner.run_tests(sbx, case, run_mounts, "vulnerable", [], "baseline_vulnerable", "/work/target",
                                  target_ro=False, timeout_s=st.baseline_timeout_s, clear_addopts=True,
                                  extra_args=targs, per_test_timeout=ptt)
    steps["baseline_vulnerable"] = {"counts": _count(base_v), "cleared_addopts": clear,
                                    "seconds": round(time.monotonic() - t, 1)}

    report_text = _report_for_agents(report, hint)
    system = (PROMPTS / "attacker_system.md").read_text(encoding="utf-8")
    task_m = Mount(case.p("task"), "/work/task", ro=True)
    env_m = Mount(case.p("env"), "/work/env", ro=True)

    # 3. blind attack on the original code (the attacker never sees the patch here)
    case.clear_dir("poc")
    case.select_tree("vulnerable")
    blind_mounts = run_mounts + [Mount(case.p("target"), "/work/target", ro=True), env_m, task_m,
                                 Mount(case.p("poc"), "/work/poc", ro=False)]
    blind_task = (PROMPTS / "attacker_blind.md").read_text(encoding="utf-8").format(report=report_text)
    steps["attacker_blind"] = _run_agent(attacker, sbx, blind_mounts, system, blind_task,
                                         case.p("logs", "agent_attacker_blind.jsonl"), st)

    poc_m = Mount(case.p("poc"), "/work/poc", ro=True)
    poc_v = runner.run_tests(sbx, case, run_mounts, "vulnerable", ["/work/poc"], "poc_vulnerable", "/work/poc",
                             extra_mounts=[poc_m], timeout_s=st.poc_timeout_s, repeat=st.poc_repeats,
                             per_test_timeout=120 if ptt else None)
    repro = rule.reproduced_tests(poc_v)
    steps["poc_vulnerable"] = {"counts": _count(poc_v), "reproduced": repro}
    if not repro:
        return finish(rule.decide(True, True, base_v, poc_v, None, None, None, None, st.min_baseline_pass))

    # 4. the same attacks on the patched code
    poc_p = runner.run_tests(sbx, case, run_mounts, "patched", repro, "poc_patched", "/work/poc",
                             extra_mounts=[poc_m], timeout_s=st.poc_timeout_s, repeat=st.poc_repeats,
                             per_test_timeout=120 if ptt else None)
    steps["poc_patched"] = {"counts": _count(poc_p)}

    # 5. project tests on the patched code
    t = time.monotonic()
    base_p = runner.run_tests(sbx, case, run_mounts, "patched", [], "baseline_patched", "/work/target",
                              target_ro=False, timeout_s=st.baseline_timeout_s, clear_addopts=clear,
                              extra_args=targs, per_test_timeout=ptt)
    passing = [k for k, v in base_v.items() if v["outcome"] == "PASS"]
    suspects = [k for k in passing if base_p.get(k, {}).get("outcome") not in ("PASS", "SKIP")]
    regressions = suspects
    if suspects:            # re-check on the original code to drop flaky tests
        recheck = runner.run_tests(sbx, case, run_mounts, "vulnerable", suspects, "baseline_recheck", "/work/target",
                                   target_ro=False, timeout_s=st.baseline_timeout_s, clear_addopts=clear,
                                   per_test_timeout=ptt)
        regressions = [k for k in suspects if recheck.get(k, {}).get("outcome") == "PASS"]
    steps["baseline_patched"] = {"counts": _count(base_p), "regressions": regressions,
                                 "flaky_dropped": sorted(set(suspects) - set(regressions)),
                                 "seconds": round(time.monotonic() - t, 1)}

    pre = rule.decide(True, True, base_v, poc_v, poc_p, regressions, None, None, st.min_baseline_pass)
    if pre.status != "verified":
        return finish(pre)          # no need to spend a white-box session on a patch that already fails

    # 6. white-box attack on the patched code
    case.clear_dir("poc_bypass")
    case.select_tree("patched")
    wb_mounts = run_mounts + [Mount(case.p("target"), "/work/target", ro=True), env_m, task_m, poc_m,
                              Mount(case.p("poc_bypass"), "/work/poc_bypass", ro=False)]
    wb_task = (PROMPTS / "attacker_whitebox.md").read_text(encoding="utf-8").format(report=report_text)
    steps["attacker_whitebox"] = _run_agent(attacker, sbx, wb_mounts, system, wb_task,
                                            case.p("logs", "agent_attacker_whitebox.jsonl"), st)
    bp_m = Mount(case.p("poc_bypass"), "/work/poc_bypass", ro=True)
    has_tests = any(case.p("poc_bypass").glob("test_*.py"))
    by_p = by_v = {}
    if has_tests:
        by_p = runner.run_tests(sbx, case, run_mounts, "patched", ["/work/poc_bypass"], "bypass_patched",
                                "/work/poc_bypass", extra_mounts=[bp_m], timeout_s=st.poc_timeout_s,
                                repeat=st.poc_repeats, per_test_timeout=120 if ptt else None)
        by_v = runner.run_tests(sbx, case, run_mounts, "vulnerable", ["/work/poc_bypass"], "bypass_vulnerable",
                                "/work/poc_bypass", extra_mounts=[bp_m], timeout_s=st.poc_timeout_s, repeat=1,
                                per_test_timeout=120 if ptt else None)
    steps["bypass"] = {"tests_written": has_tests, "patched": _count(by_p), "vulnerable": _count(by_v)}
    return finish(rule.decide(True, True, base_v, poc_v, poc_p, regressions, by_p, by_v, st.min_baseline_pass))


def _count(res: Dict[str, dict]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for v in res.values():
        out[v["outcome"]] = out.get(v["outcome"], 0) + 1
    return out
