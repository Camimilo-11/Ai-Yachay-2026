"""pytest plugin loaded by evigate's runner (-p evigate_pytest_plugin).

Writes one JSON line per event to the file named by $EVIGATE_RESULTS:
  {"event": "start", "nodeid": ...}                         before a test runs (to attribute crashes)
  {"event": "report", "nodeid", "when", "outcome", "duration", "exc_type", "is_assert", "message"}
  {"event": "collect_error", "nodeid", "exc_type", "message"}
  {"event": "session_finish", "exitstatus"}
The runner turns these into one outcome per test: PASS, ATTACK, INVALID, TIMEOUT, CRASH or SKIP.
"""
from __future__ import annotations

import json
import os

import pytest

_PATH = os.environ.get("EVIGATE_RESULTS")


def _write(rec: dict) -> None:
    if not _PATH:
        return
    with open(_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def pytest_runtest_logstart(nodeid, location):
    _write({"event": "start", "nodeid": nodeid})


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    if call.excinfo is not None:
        rep._evigate_exc_type = call.excinfo.typename
        rep._evigate_is_assert = bool(call.excinfo.errisinstance(AssertionError))
        try:
            rep._evigate_message = str(call.excinfo.value)[:500]
        except Exception:  # noqa: BLE001
            rep._evigate_message = ""


def pytest_runtest_logreport(report):
    _write({
        "event": "report", "nodeid": report.nodeid, "when": report.when, "outcome": report.outcome,
        "duration": round(float(report.duration), 3),
        "exc_type": getattr(report, "_evigate_exc_type", ""),
        "is_assert": getattr(report, "_evigate_is_assert", False),
        "message": getattr(report, "_evigate_message", ""),
    })


def pytest_collectreport(report):
    if report.failed:
        text = str(report.longrepr)[-800:] if report.longrepr is not None else ""
        _write({"event": "collect_error", "nodeid": report.nodeid, "exc_type": "CollectionError", "message": text})


def pytest_sessionfinish(session, exitstatus):
    _write({"event": "session_finish", "exitstatus": int(exitstatus)})
