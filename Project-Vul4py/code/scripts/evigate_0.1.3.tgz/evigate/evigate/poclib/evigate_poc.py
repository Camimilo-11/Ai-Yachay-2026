"""Helpers for the proof-of-concept tests that evigate's attacker writes.

A PoC test states the SAFE behaviour of the code. On the vulnerable version the attack works, so the
test fails with an AssertionError; on any correct fix it passes, whatever API the fix chose. The tests
therefore check the observable effect of the attack, never a particular exception class, message or
new parameter of one specific fix.

Helpers:
  run_isolated(fn, *args, timeout_s=..., memory_mb=..., **kwargs)
      Runs fn in a forked child with a memory limit and a wall-clock limit, so a hang, a memory blow-up or
      an interpreter crash becomes an Outcome instead of killing the test run.
  assert_bounded(outcome, what=..., max_seconds=...)
      Turns resource exhaustion (timeout, memory, crash) into an attack-succeeded assertion.
  Canary()
      For injection attacks (shell, code, path): the payload tries to create a file; the test asserts that
      the file was not created.
  assert_not_reflected(output, payload, what=...)
      For injection into output (markup, headers, logs): the attacker's payload must not come back verbatim.

Only the Python standard library is used, so the helpers work in any project environment (Linux).
"""
from __future__ import annotations

import multiprocessing as _mp
import os
import resource
import tempfile
import time
import uuid
from dataclasses import dataclass

__all__ = ["AttackSucceeded", "Outcome", "run_isolated", "assert_bounded", "Canary", "assert_not_reflected"]


class AttackSucceeded(AssertionError):
    """The observable effect of the attack happened."""


@dataclass
class Outcome:
    status: str            # returned | raised | timeout | memory | crashed
    seconds: float
    value: str = ""        # repr of the return value, truncated
    exc_type: str = ""
    exc_msg: str = ""
    signal: int = 0

    @property
    def exhausted(self) -> bool:
        return self.status in ("timeout", "memory", "crashed")


def _short(s: str, n: int = 300) -> str:
    return s if len(s) <= n else s[:n] + "...[truncated]"


def _child(conn, fn, args, kwargs, memory_mb):
    status = ("crashed", 0.0, "", "", "")
    try:
        try:                      # a crash here is an expected outcome, not something to dump a traceback for
            import faulthandler
            faulthandler.disable()
        except Exception:  # noqa: BLE001
            pass
        if memory_mb:
            limit = int(memory_mb) * 1024 * 1024
            try:
                resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
            except (ValueError, OSError):
                pass
        t0 = time.perf_counter()
        try:
            value = fn(*args, **kwargs)
            status = ("returned", time.perf_counter() - t0, _short(repr(value)), "", "")
        except MemoryError as e:
            status = ("memory", time.perf_counter() - t0, "", type(e).__name__, _short(str(e)))
        except BaseException as e:  # noqa: BLE001 - report every exception to the parent
            status = ("raised", time.perf_counter() - t0, "", type(e).__name__, _short(str(e)))
        conn.send(status)
    except BaseException:  # noqa: BLE001 - e.g. the value could not be sent
        try:
            conn.send(status)
        except BaseException:  # noqa: BLE001
            pass
    finally:
        try:
            conn.close()
        finally:
            os._exit(0)


def run_isolated(fn, *args, timeout_s: float = 10.0, memory_mb: int | None = 1024, **kwargs) -> Outcome:
    """Run fn(*args, **kwargs) in a forked child process with limits and report what happened."""
    ctx = _mp.get_context("fork")
    parent_conn, child_conn = ctx.Pipe(duplex=False)
    proc = ctx.Process(target=_child, args=(child_conn, fn, args, kwargs, memory_mb), daemon=True)
    t0 = time.perf_counter()
    proc.start()
    child_conn.close()
    try:
        ready = parent_conn.poll(timeout_s)
        if ready:
            try:
                status, secs, value, et, em = parent_conn.recv()
                proc.join(5)
                if status == "crashed":
                    return Outcome("crashed", time.perf_counter() - t0, signal=-(proc.exitcode or 0))
                return Outcome(status, secs, value, et, em)
            except (EOFError, OSError):
                proc.join(5)
                code = proc.exitcode
                return Outcome("crashed", time.perf_counter() - t0,
                               signal=-code if code is not None and code < 0 else 0)
        if proc.is_alive():
            proc.kill()
            proc.join(5)
            return Outcome("timeout", time.perf_counter() - t0)
        proc.join(5)
        code = proc.exitcode
        return Outcome("crashed", time.perf_counter() - t0, signal=-code if code is not None and code < 0 else 0)
    finally:
        parent_conn.close()
        if proc.is_alive():
            proc.kill()
            proc.join(1)


def assert_bounded(outcome: Outcome, what: str = "the call", max_seconds: float | None = None) -> Outcome:
    """Fail (attack succeeded) if the isolated call exhausted resources or exceeded max_seconds.

    A clean exception counts as safe: rejecting a malicious input is what a fix is expected to do.
    """
    if outcome.exhausted:
        detail = f" (signal {outcome.signal})" if outcome.signal else ""
        raise AttackSucceeded(f"{what} exhausted resources: {outcome.status} after {outcome.seconds:.1f} s{detail}")
    if max_seconds is not None and outcome.seconds > max_seconds:
        raise AttackSucceeded(f"{what} took {outcome.seconds:.1f} s, more than the {max_seconds} s budget")
    return outcome


class Canary:
    """A file that an injection payload tries to create; its existence proves code execution."""

    def __init__(self) -> None:
        directory = tempfile.mkdtemp(prefix="evigate_canary_")
        self.path = os.path.join(directory, "PWNED_" + uuid.uuid4().hex)

    @property
    def shell_payload(self) -> str:
        return f"touch {self.path}"

    @property
    def python_payload(self) -> str:
        return f"open({self.path!r}, 'w').close()"

    def triggered(self) -> bool:
        return os.path.exists(self.path)

    def assert_not_triggered(self, what: str = "the attack") -> None:
        if self.triggered():
            raise AttackSucceeded(f"{what} executed attacker-controlled code: the canary {self.path} was created")


def assert_not_reflected(output, payload: str, what: str = "the output") -> None:
    """Fail if the attacker's payload comes back verbatim (unescaped) in output (str or bytes)."""
    hay = output.decode("utf-8", "replace") if isinstance(output, (bytes, bytearray)) else str(output)
    if payload in hay:
        raise AttackSucceeded(f"{what} contains the attacker's payload unescaped: {payload[:80]!r}")
