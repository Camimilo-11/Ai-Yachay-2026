"""evigate: evidence-gated verification of vulnerability repairs.

A repair claim is made only with executable evidence: attack tests written without seeing the patch must
reproduce the weakness on the original code and stop working with the patch, nobody may get around the
patch, and the project's own tests must keep passing. Works on any Python repository.
"""
__version__ = "0.1.3"
