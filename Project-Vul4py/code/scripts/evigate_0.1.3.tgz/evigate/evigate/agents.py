"""Agent drivers. Each session runs in a fresh container on the `agent` network: the CLI reaches its model
API through the allowlist proxy, and the commands the agent runs reach nothing.

Supported:
  claude:<model>   Claude Code (`claude -p`) with the user's plan token in CLAUDE_CODE_OAUTH_TOKEN
  codex:<model>    Codex CLI (`codex exec`) with the user's ChatGPT login (CODEX_HOME mounted read-only)
  scripted:<dir>   copies prepared files; for the tool's own tests
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from .sandbox import Mount, Sandbox

LIMIT_MARKERS = ("usage limit", "limit reached", "hit your limit", "limit will reset", "out of extra usage",
                 "resets at", "rate limit")
AUTH_MARKERS = ("invalid bearer token", "invalid api key", "please run /login", "not logged in",
                "oauth token has expired", "authentication_error", "token has expired")
TOOL_PATH = "/opt/evigate/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


@dataclass
class AgentResult:
    ok: bool
    status: str                       # ok | limit | auth | timeout | error
    seconds: float
    final_text: str = ""
    turns: Optional[int] = None
    usage: Dict[str, object] = field(default_factory=dict)
    model_reported: str = ""
    transcript: Optional[str] = None


def _json_lines(path: Path) -> List[dict]:
    out = []
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line.startswith("{"):
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return out


class ClaudeCodeAgent:
    def __init__(self, model: str, effort: str = "high", binary: Optional[Path] = None, max_turns: int = 120,
                 timeout_s: float = 1800.0) -> None:
        self.model, self.effort, self.max_turns, self.timeout_s = model, effort, max_turns, timeout_s
        self.binary = Path(binary) if binary else _which_resolved("claude")
        self.name = f"claude:{model}"

    def run(self, sbx: Sandbox, mounts: Sequence[Mount], system_text: str, task_text: str,
            transcript: Path) -> AgentResult:
        if self.binary is None or not self.binary.exists():
            return AgentResult(False, "error", 0.0, "the claude binary was not found on this machine")
        argv = ["claude", "-p", "--model", self.model, "--effort", self.effort,
                "--output-format", "stream-json", "--verbose", "--max-turns", str(self.max_turns),
                "--permission-mode", "bypassPermissions",
                "--disallowedTools", "WebFetch,WebSearch,Task,Agent,mcp__*",
                "--append-system-prompt", system_text, "--no-session-persistence"]
        env = {"PATH": TOOL_PATH, "PYTHONPATH": "/opt/evigate", "EVIGATE_POCLIB": "/opt/evigate/evigate/poclib",
               "DISABLE_TELEMETRY": "1", "DISABLE_ERROR_REPORTING": "1", "DISABLE_AUTOUPDATER": "1",
               "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1", "IS_SANDBOX": "1"}
        all_mounts = list(mounts) + [Mount(self.binary, "/usr/local/bin/claude", ro=True)]
        if transcript.exists():
            transcript.unlink()
        t0 = time.monotonic()
        res = sbx.run(argv, all_mounts, network="agent", env=env, passthrough=["CLAUDE_CODE_OAUTH_TOKEN"],
                      workdir="/work", timeout_s=self.timeout_s, log_path=transcript, stdin_text=task_text)
        events = _json_lines(transcript)
        final = next((e for e in reversed(events) if e.get("type") == "result"), {})
        text = str(final.get("result", "") or "")
        raw = transcript.read_text(encoding="utf-8", errors="replace").lower() if transcript.exists() else ""
        model_rep = ",".join((final.get("modelUsage") or {}).keys())
        usage = {"usage": final.get("usage"), "total_cost_usd_equivalent": final.get("total_cost_usd"),
                 "num_turns": final.get("num_turns")}
        if res.timed_out:
            status = "timeout"
        elif any(m in raw[-4000:] for m in AUTH_MARKERS):
            status = "auth"
        elif (final.get("is_error") or not final) and any(m in raw[-4000:] for m in LIMIT_MARKERS):
            status = "limit"
        elif final and not final.get("is_error"):
            status = "ok"
        else:
            status = "error"
        return AgentResult(status == "ok", status, time.monotonic() - t0, text[-4000:], final.get("num_turns"),
                           usage, model_rep, str(transcript))


class CodexAgent:
    def __init__(self, model: str, effort: str = "high", binary: Optional[Path] = None,
                 codex_home: Optional[Path] = None, timeout_s: float = 2400.0) -> None:
        self.model, self.effort, self.timeout_s = model, effort, timeout_s
        self.binary = Path(binary) if binary else _which_resolved("codex")
        self.codex_home = Path(codex_home) if codex_home else Path.home() / ".codex"
        self.name = f"codex:{model}"

    def run(self, sbx: Sandbox, mounts: Sequence[Mount], system_text: str, task_text: str,
            transcript: Path) -> AgentResult:
        if self.binary is None or not self.binary.exists():
            return AgentResult(False, "error", 0.0, "the codex binary was not found on this machine")
        argv = ["codex", "exec", "--model", self.model, "-c", f"model_reasoning_effort={self.effort}",
                "--sandbox", "danger-full-access", "--skip-git-repo-check", "--json", "-"]
        env = {"PATH": TOOL_PATH, "PYTHONPATH": "/opt/evigate", "EVIGATE_POCLIB": "/opt/evigate/evigate/poclib",
               "CODEX_HOME": "/home/agent/.codex"}
        home = transcript.parent / f"{transcript.stem}_codex_home"
        if home.exists():
            shutil.rmtree(home)
        shutil.copytree(self.codex_home, home, ignore=shutil.ignore_patterns("sessions", "log", "*.sqlite*"))
        all_mounts = list(mounts) + [Mount(self.binary, "/usr/local/bin/codex", ro=True),
                                     Mount(home, "/home/agent/.codex", ro=False)]
        if transcript.exists():
            transcript.unlink()
        t0 = time.monotonic()
        res = sbx.run(argv, all_mounts, network="agent", env=env, workdir="/work", timeout_s=self.timeout_s,
                      log_path=transcript, stdin_text=system_text + "\n\n" + task_text)
        shutil.rmtree(home, ignore_errors=True)      # never keep a copy of the login
        events = _json_lines(transcript)
        raw = transcript.read_text(encoding="utf-8", errors="replace").lower() if transcript.exists() else ""
        text = ""
        for e in reversed(events):
            msg = e.get("msg") or e.get("item") or {}
            if isinstance(msg, dict) and msg.get("type") in ("agent_message", "assistant_message"):
                text = str(msg.get("message") or msg.get("text") or "")
                break
        status = ("timeout" if res.timed_out else "auth" if any(m in raw[-4000:] for m in AUTH_MARKERS)
                  else "limit" if any(m in raw[-4000:] for m in LIMIT_MARKERS) and res.rc != 0
                  else "ok" if res.rc == 0 else "error")
        return AgentResult(status == "ok", status, time.monotonic() - t0, text[-4000:], None, {}, self.model,
                           str(transcript))


class ScriptedAgent:
    """Copies prepared files into the writable mount; used by the tool's tests instead of a model."""

    def __init__(self, files_dir: Path) -> None:
        self.files_dir = Path(files_dir)
        self.name = f"scripted:{self.files_dir.name}"

    def run(self, sbx: Sandbox, mounts: Sequence[Mount], system_text: str, task_text: str,
            transcript: Path) -> AgentResult:
        out = next((m for m in mounts if not m.ro and m.target in ("/work/poc", "/work/poc_bypass")), None)
        t0 = time.monotonic()
        src = self.files_dir / Path(out.target).name if out else None   # <dir>/poc or <dir>/poc_bypass
        if out and src and src.exists():
            for p in src.iterdir():
                if p.is_file():
                    shutil.copy2(p, Path(out.host) / p.name)
        transcript.write_text(json.dumps({"type": "result", "result": "scripted", "is_error": False}) + "\n")
        return AgentResult(True, "ok", time.monotonic() - t0, "scripted", 0, {}, "scripted", str(transcript))


def make_agent(spec: str, effort: str = "high", timeout_s: float = 1800.0):
    kind, _, rest = spec.partition(":")
    if kind == "claude":
        return ClaudeCodeAgent(rest, effort=effort, timeout_s=timeout_s)
    if kind == "codex":
        return CodexAgent(rest, effort=effort, timeout_s=timeout_s)
    if kind == "scripted":
        return ScriptedAgent(Path(rest))
    raise ValueError(f"unknown agent spec {spec!r} (use claude:<model>, codex:<model> or scripted:<dir>)")


def _which_resolved(name: str) -> Optional[Path]:
    p = shutil.which(name)
    return Path(p).resolve() if p else None
