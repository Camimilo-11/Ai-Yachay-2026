"""Offline weakness catalogue built from MITRE's public CWE and CAPEC XML ("graph-lite" retrieval).

Each CWE entry keeps its description, consequences, mitigations, detection methods, its relations to other
weaknesses (ChildOf, ParentOf, PeerOf, CanPrecede, CanFollow) and the CAPEC attack patterns linked to it,
with their execution flow. That gives an agent, offline, the variants a complete fix must stop.

To keep the evaluation clean the catalogue drops everything tied to specific products or vulnerabilities:
Observed_Examples, References, Demonstrative_Examples, Example_Instances, and any sentence that cites a
CVE or GHSA identifier. The built file records the source versions and hashes.

  evigate kb build --cwe cwec_latest.xml[.zip] --capec capec_latest.xml [--out evigate/data/kb.json]
  evigate kb search "xml entity expansion"
  evigate kb show CWE-776 | CAPEC-197
  evigate kb info
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import math
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Dict, List

DATA = Path(__file__).resolve().parent / "data" / "kb.json"
DROP = {"Observed_Examples", "References", "Demonstrative_Examples", "Example_Instances", "Content_History",
        "Notes", "Taxonomy_Mappings", "Mapping_Notes"}
ID_RE = re.compile(r"\b(CVE-\d{4}-\d{3,}|GHSA(-[0-9a-z]{4}){3})\b", re.I)
TOKEN = re.compile(r"[a-z0-9]+")


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _text(el) -> str:
    if el is None:
        return ""
    s = " ".join(" ".join(t.split()) for t in el.itertext())
    s = re.sub(r"\s+", " ", s).strip()
    # drop sentences that cite specific vulnerabilities
    sentences = re.split(r"(?<=[.!?])\s+", s)
    return " ".join(x for x in sentences if not ID_RE.search(x))


def _child(el, name):
    for c in el:
        if _local(c.tag) == name:
            return c
    return None


def _children(el, name):
    return [c for c in el if _local(c.tag) == name] if el is not None else []


def _load_xml(path: Path) -> ET.Element:
    data = Path(path).read_bytes()
    if path.suffix == ".zip":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            name = next(n for n in z.namelist() if n.endswith(".xml"))
            data = z.read(name)
    return ET.fromstring(data)


def build(cwe_path: Path, capec_path: Path, out: Path = DATA) -> dict:
    cwe_root = _load_xml(Path(cwe_path))
    capec_root = _load_xml(Path(capec_path))
    weaknesses: Dict[str, dict] = {}
    for w in cwe_root.iter():
        if _local(w.tag) != "Weakness":
            continue
        wid = f"CWE-{w.get('ID')}"
        rel = [{"nature": r.get("Nature"), "id": f"CWE-{r.get('CWE_ID')}", "view": r.get("View_ID")}
               for r in _children(_child(w, "Related_Weaknesses"), "Related_Weakness")]
        weaknesses[wid] = {
            "id": wid, "name": w.get("Name", ""), "abstraction": w.get("Abstraction", ""),
            "status": w.get("Status", ""),
            "description": _text(_child(w, "Description")),
            "extended": _text(_child(w, "Extended_Description"))[:4000],
            "languages": sorted({l.get("Name") or l.get("Class") or "" for l in
                                 _children(_child(w, "Applicable_Platforms"), "Language")} - {""}),
            "consequences": [{"scope": [_text(s) for s in _children(c, "Scope")],
                              "impact": [_text(i) for i in _children(c, "Impact")],
                              "note": _text(_child(c, "Note"))[:400]}
                             for c in _children(_child(w, "Common_Consequences"), "Consequence")],
            "mitigations": [{"phase": [_text(p) for p in _children(m, "Phase")],
                             "strategy": _text(_child(m, "Strategy")),
                             "text": _text(_child(m, "Description"))[:1200]}
                            for m in _children(_child(w, "Potential_Mitigations"), "Mitigation")],
            "detection": [{"method": _text(_child(d, "Method")), "text": _text(_child(d, "Description"))[:500]}
                          for d in _children(_child(w, "Detection_Methods"), "Detection_Method")],
            "related": rel,
            "capec": [f"CAPEC-{p.get('CAPEC_ID')}" for p in
                      _children(_child(w, "Related_Attack_Patterns"), "Related_Attack_Pattern")],
        }
    # reverse edges so a parent knows its children
    for wid, w in weaknesses.items():
        for r in w["related"]:
            if r["nature"] == "ChildOf" and r["id"] in weaknesses:
                weaknesses[r["id"]].setdefault("children", [])
                if wid not in weaknesses[r["id"]]["children"]:
                    weaknesses[r["id"]]["children"].append(wid)
    patterns: Dict[str, dict] = {}
    for a in capec_root.iter():
        if _local(a.tag) != "Attack_Pattern":
            continue
        aid = f"CAPEC-{a.get('ID')}"
        patterns[aid] = {
            "id": aid, "name": a.get("Name", ""), "abstraction": a.get("Abstraction", ""),
            "status": a.get("Status", ""),
            "description": _text(_child(a, "Description"))[:2000],
            "prerequisites": [_text(p)[:400] for p in _children(_child(a, "Prerequisites"), "Prerequisite")],
            "steps": [{"phase": _text(_child(s, "Phase")), "text": _text(_child(s, "Description"))[:500],
                       "techniques": [_text(t)[:300] for t in _children(s, "Technique")]}
                      for s in _children(_child(a, "Execution_Flow"), "Attack_Step")],
            "mitigations": [_text(m)[:500] for m in _children(_child(a, "Mitigations"), "Mitigation")],
            "weaknesses": [f"CWE-{r.get('CWE_ID')}" for r in
                           _children(_child(a, "Related_Weaknesses"), "Related_Weakness")],
        }
    meta = {
        "built_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "cwe_version": cwe_root.get("Version"), "cwe_date": cwe_root.get("Date"),
        "capec_version": capec_root.get("Version"), "capec_date": capec_root.get("Date"),
        "cwe_source_sha256": hashlib.sha256(Path(cwe_path).read_bytes()).hexdigest(),
        "capec_source_sha256": hashlib.sha256(Path(capec_path).read_bytes()).hexdigest(),
        "dropped_sections": sorted(DROP), "dropped_sentences": "any sentence citing a CVE or GHSA id",
        "counts": {"weaknesses": len(weaknesses), "attack_patterns": len(patterns)},
    }
    kb = {"meta": meta, "weaknesses": weaknesses, "attack_patterns": patterns}
    leaks = ID_RE.findall(json.dumps(kb))
    if leaks:
        raise SystemExit(f"leak filter failed: {len(leaks)} identifiers remain")
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(kb, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    meta["kb_sha256"] = hashlib.sha256(out.read_bytes()).hexdigest()
    return meta


def _load() -> dict:
    if not DATA.exists():
        raise SystemExit("The CWE/CAPEC catalogue is not built yet (evigate kb build). Continue without it.")
    return json.loads(DATA.read_text(encoding="utf-8"))


def search(kb: dict, query: str, n: int = 10) -> List[dict]:
    docs = list(kb["weaknesses"].values()) + list(kb["attack_patterns"].values())
    toks = [TOKEN.findall((d["name"] + " " + d["name"] + " " + d["description"] + " " +
                           d.get("extended", "")).lower()) for d in docs]
    q = TOKEN.findall(query.lower())
    N = len(docs)
    avg = sum(len(t) for t in toks) / max(N, 1)
    dfs = Counter(w for t in toks for w in set(t))
    scored = []
    for d, t in zip(docs, toks):
        tf = Counter(t)
        s = 0.0
        for w in q:
            if w in tf:
                idf = math.log(1 + (N - dfs[w] + 0.5) / (dfs[w] + 0.5))
                s += idf * tf[w] * 2.2 / (tf[w] + 1.2 * (0.25 + 0.75 * len(t) / avg))
        if s > 0 and d.get("status") != "Deprecated":
            scored.append((s, d))
    scored.sort(key=lambda x: -x[0])
    return [{"id": d["id"], "name": d["name"], "abstraction": d.get("abstraction", ""), "score": round(s, 2)}
            for s, d in scored[:n]]


def show(kb: dict, ident: str) -> str:
    ident = ident.upper().strip()
    if ident.isdigit():
        ident = "CWE-" + ident
    W, A = kb["weaknesses"], kb["attack_patterns"]
    lines: List[str] = []
    if ident in W:
        w = W[ident]
        lines += [f"{w['id']}: {w['name']} [{w['abstraction']}]", "", w["description"]]
        if w["extended"]:
            lines += ["", w["extended"][:2500]]
        rel = {}
        for r in w["related"]:
            rel.setdefault(r["nature"], set()).add(r["id"])
        for nature, ids in sorted(rel.items()):
            lines.append(f"\n{nature}: " + "; ".join(f"{i} {W[i]['name']}" if i in W else i for i in sorted(ids)))
        if w.get("children"):
            lines.append("\nParentOf (more specific variants): " +
                         "; ".join(f"{i} {W[i]['name']}" for i in sorted(w["children"]) if i in W))
        if w["consequences"]:
            lines.append("\nConsequences: " + "; ".join(", ".join(c["impact"]) for c in w["consequences"]))
        if w["mitigations"]:
            lines.append("\nMitigations:")
            lines += [f"- [{'/'.join(m['phase'])}] {m['text']}" for m in w["mitigations"][:8]]
        for cid in w["capec"][:6]:
            if cid in A:
                a = A[cid]
                lines.append(f"\nAttack pattern {cid}: {a['name']}. {a['description'][:600]}")
                for s in a["steps"][:6]:
                    lines.append(f"  - {s['phase']}: {s['text'][:300]}")
        return "\n".join(lines)
    if ident in A:
        a = A[ident]
        lines += [f"{a['id']}: {a['name']} [{a['abstraction']}]", "", a["description"]]
        if a["prerequisites"]:
            lines.append("\nPrerequisites: " + " | ".join(a["prerequisites"][:5]))
        for s in a["steps"]:
            lines.append(f"- {s['phase']}: {s['text']}")
            lines += [f"    technique: {t}" for t in s["techniques"][:4]]
        if a["mitigations"]:
            lines.append("\nMitigations: " + " | ".join(a["mitigations"][:6]))
        lines.append("\nWeaknesses: " + "; ".join(f"{i} {W[i]['name']}" if i in W else i for i in a["weaknesses"]))
        return "\n".join(lines)
    return f"{ident}: not in the catalogue"


def main(argv: List[str]) -> int:
    ap = argparse.ArgumentParser(prog="evigate kb")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--cwe", required=True)
    b.add_argument("--capec", required=True)
    b.add_argument("--out", default=str(DATA))
    s = sub.add_parser("search")
    s.add_argument("words", nargs="+")
    s.add_argument("-n", type=int, default=10)
    sh = sub.add_parser("show")
    sh.add_argument("ident")
    sub.add_parser("info")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        print(json.dumps(build(Path(a.cwe), Path(a.capec), Path(a.out)), indent=2))
        return 0
    kb = _load()
    if a.cmd == "search":
        for r in search(kb, " ".join(a.words), a.n):
            print(f"{r['id']:11} {r['score']:6}  {r['name']} [{r['abstraction']}]")
    elif a.cmd == "show":
        print(show(kb, a.ident))
    else:
        print(json.dumps(kb["meta"], indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
