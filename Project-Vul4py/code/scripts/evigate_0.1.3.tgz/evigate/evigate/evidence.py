"""The evidence package of one case: verdict.json plus a SHA-256 manifest of everything it relies on."""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Iterable

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
EXCLUDE_TOP = {"target", "trees", "home"}            # copies of the input (their digests are in verdict.json)
EXCLUDE_ANY = {".venv", "__pycache__"}


def tool_digest() -> str:
    """Hash of the tool's own source (the code that produced a verdict)."""
    h = hashlib.sha256()
    for p in sorted((PACKAGE_ROOT / "evigate").rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix in (".py", ".md"):
            h.update(str(p.relative_to(PACKAGE_ROOT)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def _files(root: Path) -> Iterable[Path]:
    for dirpath, dirs, files in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        dirs[:] = [d for d in dirs if d not in EXCLUDE_ANY and not (rel == Path(".") and d in EXCLUDE_TOP)]
        for f in files:
            p = Path(dirpath) / f
            if p.is_file() and not p.is_symlink() and f != "MANIFEST.sha256":
                yield p


def write_manifest(root: Path) -> Path:
    root = Path(root)
    lines = []
    for p in sorted(_files(root)):
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        lines.append(f"{h}  {p.relative_to(root)}")
    out = root / "MANIFEST.sha256"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out
