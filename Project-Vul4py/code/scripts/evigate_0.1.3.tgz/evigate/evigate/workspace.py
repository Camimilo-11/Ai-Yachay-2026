"""The case directory: clean copies of the code, the patch, and file hashes.

Layout (host side; the sandbox mounts these at /work/...):
  task/        report.md, hint.md (optional), patch.diff (verify mode), notes for the agents
  trees/vulnerable/   clean copy of the code as received
  trees/patched/      the same with the patch applied
  target/      the tree under test right now (a copy of one of the trees, refreshed before every run)
  env/         the project's virtual environment and its manifest
  poc/ poc_bypass/    the attacker's tests
  results/ logs/      runner results (JSON lines) and logs of every command and agent session
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

VCS_DIRS = {".git", ".hg", ".svn", ".bzr"}
CACHE_DIRS = {"__pycache__", ".tox", ".nox", ".mypy_cache", ".pytest_cache", ".ruff_cache", ".hypothesis",
              ".eggs", "node_modules"}
TOP_LEVEL_BUILD = {"build", "dist"}


def _is_venv(d: Path) -> bool:
    return (d / "pyvenv.cfg").is_file()


def copy_clean(src: Path, dst: Path) -> Dict[str, int]:
    """Copy a source tree without version control data, virtual environments, caches or build outputs.

    Symlinks are kept only when they stay inside the tree; links that point outside are dropped, so a
    tree can never expose files from elsewhere on the machine.
    """
    src, dst = Path(src).resolve(), Path(dst)
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    stats = {"files": 0, "skipped_dirs": 0, "dropped_links": 0}
    for root, dirs, files in os.walk(src):
        r = Path(root)
        rel = r.relative_to(src)
        keep = []
        for d in dirs:
            p = r / d
            if d in VCS_DIRS or d in CACHE_DIRS or d.endswith(".egg-info") or _is_venv(p) \
                    or (rel == Path(".") and d in TOP_LEVEL_BUILD):
                stats["skipped_dirs"] += 1
                continue
            if p.is_symlink():
                if _link_inside(p, src):
                    (dst / rel / d).parent.mkdir(parents=True, exist_ok=True)
                    os.symlink(os.readlink(p), dst / rel / d)
                else:
                    stats["dropped_links"] += 1
                continue
            keep.append(d)
        dirs[:] = keep
        (dst / rel).mkdir(parents=True, exist_ok=True)
        for f in files:
            p = r / f
            if f == ".git":           # worktree pointer file
                continue
            if p.is_symlink():
                if _link_inside(p, src):
                    os.symlink(os.readlink(p), dst / rel / f)
                else:
                    stats["dropped_links"] += 1
                continue
            shutil.copy2(p, dst / rel / f)
            stats["files"] += 1
    return stats


def _link_inside(link: Path, root: Path) -> bool:
    try:
        target = (link.parent / os.readlink(link)).resolve()
        return target == root or root in target.parents
    except OSError:
        return False


def tree_manifest(tree: Path) -> Dict[str, str]:
    out = {}
    for p in sorted(Path(tree).rglob("*")):
        if p.is_file() and not p.is_symlink():
            out[str(p.relative_to(tree))] = sha256_file(p)
    return out


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def manifest_digest(manifest: Dict[str, str]) -> str:
    return sha256_text(json.dumps(manifest, sort_keys=True))


def patched_files(patch_text: str) -> List[str]:
    files = []
    for line in patch_text.splitlines():
        if line.startswith("+++ "):
            path = line[4:].split("\t")[0].strip()
            if path != "/dev/null":
                files.append(path[2:] if path.startswith(("a/", "b/")) else path)
    return files


def apply_patch(tree: Path, patch_file: Path, log: Path) -> Tuple[bool, str]:
    """Apply a unified diff inside tree. Tries git apply (strict, then 3-way-free with fuzz) and GNU patch."""
    attempts = [
        ["git", "apply", "--verbose", "--whitespace=nowarn", str(patch_file)],
        ["git", "apply", "--verbose", "--whitespace=nowarn", "--recount", "-C1", str(patch_file)],
        ["patch", "-p1", "--forward", "--batch", "--no-backup-if-mismatch", "-i", str(patch_file)],
    ]
    # Never let git discover a repository above the tree (the case may live inside one).
    env = dict(os.environ, GIT_CEILING_DIRECTORIES=str(Path(tree).resolve().parent))
    with open(log, "a", encoding="utf-8") as lf:
        for argv in attempts:
            if shutil.which(argv[0]) is None:
                continue
            cp = subprocess.run(argv, cwd=tree, capture_output=True, text=True, env=env)
            lf.write(f"$ {' '.join(argv)}\n{cp.stdout}{cp.stderr}[exit {cp.returncode}]\n")
            if cp.returncode == 0:
                return True, " ".join(argv[:2])
    return False, "the patch does not apply"


class Case:
    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        for d in ("task", "trees", "target", "env", "poc", "poc_bypass", "results", "logs", "home"):
            (self.root / d).mkdir(parents=True, exist_ok=True)

    def p(self, *parts: str) -> Path:
        return self.root.joinpath(*parts)

    def select_tree(self, which: str) -> None:
        """Make target/ an exact copy of trees/<which>."""
        src = self.p("trees", which)
        dst = self.p("target")
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst, symlinks=True)

    def write_json(self, rel: str, data) -> Path:
        path = self.p(rel)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        return path

    def clear_dir(self, rel: str) -> None:
        d = self.p(rel)
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)


def prepare_case(root: Path, repo: Path, report: str, hint: Optional[str], patch: Optional[str]) -> Tuple[Case, dict]:
    case = Case(root)
    info = {}
    case.p("task", "report.md").write_text(report, encoding="utf-8")
    if hint:
        case.p("task", "hint.md").write_text(hint, encoding="utf-8")
    info["copy_vulnerable"] = copy_clean(repo, case.p("trees", "vulnerable"))
    info["vulnerable_manifest"] = manifest_digest(tree_manifest(case.p("trees", "vulnerable")))
    if patch is not None:
        pf = case.p("task", "patch.diff")
        pf.write_text(patch, encoding="utf-8")
        if case.p("trees", "patched").exists():
            shutil.rmtree(case.p("trees", "patched"))
        shutil.copytree(case.p("trees", "vulnerable"), case.p("trees", "patched"), symlinks=True)
        ok, how = apply_patch(case.p("trees", "patched"), pf, case.p("logs", "apply_patch.log"))
        info["patch_applies"] = ok
        info["patch_apply_method"] = how
        info["patch_files"] = patched_files(patch)
        info["patch_sha256"] = sha256_text(patch)
        if ok:
            info["patched_manifest"] = manifest_digest(tree_manifest(case.p("trees", "patched")))
    case.select_tree("vulnerable")
    return case, info
