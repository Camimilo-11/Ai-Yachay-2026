"""evigate command line.

  evigate verify --repo DIR --report FILE --patch FILE --out DIR [--hint FILE] [--attacker claude:<model>] ...
      Decide whether a patch can be claimed as a verified repair, with executable evidence. Works on any
      Python repository; the report can be an advisory, a CVE text, a scanner finding or location hints.
  evigate run PATH...            (inside the sandbox) run attack tests against /work/target, one outcome per test
  evigate kb search WORDS | show CWE-ID   (inside or outside the sandbox) offline CWE/CAPEC catalogue
  evigate docker-setup           build the sandbox image, the internal network and the egress proxy

Exit codes: 0 verdict written (whatever it says); 2 bad usage; 3 an agent could not authenticate.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _read(path):
    return Path(path).read_text(encoding="utf-8") if path else None


def cmd_verify(a) -> int:
    from .agents import make_agent
    from .pipeline import AuthFailure, Settings, verify
    from .sandbox import DockerSettings, Limits, Sandbox
    sbx = Sandbox(a.backend, Limits(memory_mb=a.memory_mb, cpus=a.cpus, pids=a.pids),
                  DockerSettings(image=a.image))
    import shlex
    st = Settings(python=a.python, constraints=_read(a.constraints), exclude_newer=a.exclude_newer,
                  setup_script=_read(a.setup_script), test_args=tuple(shlex.split(a.test_args or "")),
                  poc_repeats=a.repeats, min_baseline_pass=a.min_baseline_pass)
    attacker = make_agent(a.attacker, effort=a.effort, timeout_s=a.agent_timeout)
    try:
        state = verify(Path(a.repo), _read(a.report), _read(a.patch), Path(a.out), attacker, sbx,
                       hint=_read(a.hint), st=st)
    except AuthFailure as e:
        print(f"[evigate] {e}", file=sys.stderr)
        return 3
    v = state["verdict"]
    print(json.dumps({"claim": v["claim"], "status": v["status"], "reasons": v["reasons"][:5],
                      "counts": v["counts"], "seconds": state["seconds"]}, indent=2))
    return 0


def cmd_run(a) -> int:
    from .runner import format_table, run_here
    res = run_here(a.paths, timeout_s=a.timeout)
    print(format_table(res))
    return 0


def cmd_kb(a) -> int:
    from . import kb
    return kb.main(a.kb_args)


def cmd_docker_setup(a) -> int:
    from . import dockerctl
    return dockerctl.setup(rebuild=a.rebuild)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="evigate", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    v = sub.add_parser("verify", help="verify a patch with executable evidence")
    v.add_argument("--repo", required=True, help="the vulnerable source tree (any Python project)")
    v.add_argument("--report", required=True, help="text file: advisory, CVE text, scanner finding or location hints")
    v.add_argument("--patch", required=True, help="unified diff to verify")
    v.add_argument("--out", required=True, help="case directory for the evidence")
    v.add_argument("--hint", help="optional text file with locations (files and lines)")
    v.add_argument("--attacker", default="claude:claude-opus-5-5", help="claude:<model>, codex:<model> or scripted:<dir>")
    v.add_argument("--effort", default="high")
    v.add_argument("--agent-timeout", type=float, default=1800.0)
    v.add_argument("--python", help="Python version for the project (default: detected from its metadata)")
    v.add_argument("--constraints", help="optional lock/constraints file with dependency versions")
    v.add_argument("--exclude-newer", help="optional date: ignore dependency releases after it")
    v.add_argument("--setup-script", help="optional build recipe, one shell command per line, run from the repo root")
    v.add_argument("--test-args", help="optional extra pytest arguments for the project's own tests")
    v.add_argument("--repeats", type=int, default=2, help="runs of each attack test per tree (all must agree)")
    v.add_argument("--min-baseline-pass", type=int, default=1)
    v.add_argument("--backend", choices=["docker", "local"], default="docker")
    v.add_argument("--image", default="evigate-sandbox:0.1")
    v.add_argument("--memory-mb", type=int, default=3072)
    v.add_argument("--cpus", type=float, default=1.5)
    v.add_argument("--pids", type=int, default=512)
    v.set_defaults(func=cmd_verify)

    r = sub.add_parser("run", help="(inside the sandbox) run attack tests against /work/target")
    r.add_argument("paths", nargs="+")
    r.add_argument("--timeout", type=float, default=300.0)
    r.set_defaults(func=cmd_run)

    k = sub.add_parser("kb", help="offline CWE/CAPEC catalogue")
    k.add_argument("kb_args", nargs=argparse.REMAINDER)
    k.set_defaults(func=cmd_kb)

    d = sub.add_parser("docker-setup", help="build the sandbox image, network and egress proxy")
    d.add_argument("--rebuild", action="store_true")
    d.set_defaults(func=cmd_docker_setup)

    a = ap.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
