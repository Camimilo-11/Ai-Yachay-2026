---
name: verificar-reparacion
description: Verify whether a security patch to a Python project really fixes the vulnerability, with executable evidence (evigate). Use when someone asks to check, verify or audit a vulnerability fix or a security patch, or to confirm that a CVE is fixed in their code.
---

# Verify a security repair with evidence (evigate)

Use evigate instead of judging the diff by reading it: a repair claim needs executable evidence.

1. Collect three inputs and save them as files: the project folder (the code BEFORE the patch), the report (an advisory, CVE text, scanner finding or file/line hints) and the patch as a unified diff. If the user only has the patched code, ask for the version before the fix or the diff.
2. Check that Docker works (`docker info`) and that the sandbox is set up (`python3 -m evigate docker-setup` once). If the user's Claude plan token is not loaded, ask them to run `read -rs CLAUDE_CODE_OAUTH_TOKEN && export CLAUDE_CODE_OAUTH_TOKEN` themselves. Never ask them to paste it.
3. Run:
   `python3 -m evigate verify --repo <folder> --report <report> --patch <diff> --out <case-folder> --attacker claude:claude-opus-5-5`
4. Read `<case-folder>/verdict.json` and report the status in plain words:
   - `verified`: attacks written without seeing the patch reproduced the vulnerability, the patch stops all of them, no bypass was found and the project's tests still pass. Say it is strong evidence, not a proof.
   - Any other status: the patch cannot be claimed as a repair. Explain the reason (`not_blocked`, `bypass`, `regression`, `not_reproduced`, `env_failed`...) and point to the failing test in `<case-folder>/poc` or `poc_bypass`.
5. Offer the evidence package: `verdict.json` and `MANIFEST.sha256` in the case folder.

Never edit the attack tests to make a patch pass, and never report "verified" from your own reading of the code.
