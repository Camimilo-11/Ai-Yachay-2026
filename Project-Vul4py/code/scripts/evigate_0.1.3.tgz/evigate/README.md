# evigate: evidence-gated verification of vulnerability repairs

evigate decides whether a security patch can be **claimed** as a repair, and it only says "verified" with executable evidence. It works on any Python repository: the input is the code, a report of the vulnerability and the patch. Nothing in the tool knows about any benchmark.

The rule behind it: a repair claim needs independent evidence. Opinions about a diff, including those of a jury of models, did not stop false assurance in our experiments; execution can.

## What it does with one case

1. **Clean copy.** The code is copied without version-control history, virtual environments, caches or build output. Symlinks that point outside the tree are dropped.
2. **Environment.** It builds the project's environment with uv. The Python version is detected from the project's metadata unless you give one, and a constraints file and a release cut-off date are optional. Then it runs the project's own tests on the original code to get a functional baseline.
3. **Blind attack.** An attacker agent from another model family than the one that wrote the patch reads the report and the original code. It never sees the patch. It writes pytest attack tests that state the *safe* behaviour, so each one fails on vulnerable code. A test counts only if it reproduces the vulnerability (`ATTACK`) in every repetition. The tests check the attack's effect, not the shape of a particular fix: no canary file created, bounded time and memory, forged token rejected, payload not reflected.
4. **Deterministic verification.** Without any model, the reproduced attacks run on the patched code and must all `PASS`. The project tests that passed before must still pass, re-checked on the original code to drop flaky ones.
5. **White-box attack.** A fresh attacker session sees the patch and tries to get around it. A bypass counts only if it runs (`ATTACK` on the patched code).
6. **Claim rule.** `verified` only if every step above holds. Otherwise the status says why:

   | Status | Meaning |
   | --- | --- |
   | `patch_does_not_apply` | The patch does not apply to the code |
   | `env_failed` | The environment could not be built |
   | `no_functional_evidence` | No project test passes on the original code |
   | `not_reproduced` | No attack test reproduced the vulnerability |
   | `not_blocked` | A reproduced attack still works with the patch |
   | `inconclusive` | A reproduced attack errors on the patched code |
   | `regression` | A project test fails only with the patch |
   | `bypass` | The white-box attacker got around the patch |
   | `introduced_weakness` | An attack works on the patched code but not on the original |

7. **Evidence.** `verdict.json` holds the inputs' hashes, the environment, every test outcome, the agent sessions (model, time, usage, transcript hash) and the verdict. `MANIFEST.sha256` covers every file, so a person can audit the claim when there is no oracle.

## Security of the tool itself

The agents run code from untrusted repositories and attack payloads, so every command runs in a container:

- **Network.** Only the agent CLI can reach its model API, through an allowlist proxy on an internal Docker network (`api.anthropic.com`, `chatgpt.com`, `auth.openai.com`, `api.openai.com`). The agent's commands cannot download a fix or send data anywhere else. Test runs have no network at all. The environment build is the only step with normal egress, and no agent runs there.
- **Limits.** Memory, CPU and process limits apply, because many proofs of concept are resource bombs. Containers also run with a read-only root filesystem, no capabilities, `no-new-privileges` and the host's user id.
- **Mounts.** Only the needed directories are mounted. The code under test is read-only for the attacker, and the blind attacker never gets the patch.
- **Secrets.** The plan token (`CLAUDE_CODE_OAUTH_TOKEN`) is passed from the shell's environment, never written to disk. A Codex login is copied into the session and deleted after it.

`evigate docker-setup` builds the image, the network and the proxy, then self-tests from the agent network that the model API is reachable while PyPI and GitHub are refused, and that the no-network mode reaches nothing.

## Usage

```bash
# once, on a Linux machine with Docker (your user in the docker group)
python3 -m evigate docker-setup

# the attacker runs with your Claude plan; load the token without writing it anywhere
read -rs CLAUDE_CODE_OAUTH_TOKEN && export CLAUDE_CODE_OAUTH_TOKEN

python3 -m evigate verify --repo ./project --report advisory.txt --patch fix.diff --out ./case \
    --attacker claude:claude-opus-5-5 [--hint locations.txt] [--python 3.10] [--constraints lock.txt]
```

The report can be an advisory, a CVE description, a scanner finding or location hints. The exit code is 0 whenever a verdict was written, whatever it says, and 3 if the agent could not authenticate.

The repository also has an offline weakness catalogue built from MITRE's public CWE and CAPEC data (`python3 -m evigate kb build ...`). Agents query it inside the sandbox with `evigate-kb search` and `evigate-kb show CWE-<id>`. To keep evaluations clean it drops observed examples, references and any sentence citing a CVE or GHSA identifier.

## Measuring it

Outside a benchmark there is no oracle: `verified` means that this evidence held, and the evidence package is what a person checks. To *measure* how often `verified` is wrong, run evigate on a benchmark through an adapter that hands it only what a user would have, then compare against the benchmark's hidden oracle. For Vul4Py, `scripts/evigate_vul4py.py` in the experiment repository does exactly that.

## Tests

`python3 -m pytest tests/` runs the tool's own tests on a toy project with scripted attackers and the local backend, so no models or Docker are needed. The local backend gives no isolation and is for development only.

## Limitations

- **Attack tests come from a model.** A test that passes on a weak patch is possible. The blind phase, the reproduction requirement and the white-box phase reduce that risk; they do not remove it. That is why the measurement on a benchmark with a hidden oracle matters.
- **Abstention.** When the vulnerability cannot be reproduced, or the environment cannot be built, the tool abstains rather than claims. Report coverage together with the false-assurance rate.
- **Memorization.** Models may have seen the public fix of an old vulnerability during training.
