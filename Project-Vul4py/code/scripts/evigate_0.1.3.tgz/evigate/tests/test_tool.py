"""Tests of evigate itself, on a toy project, with the local backend and scripted attackers (no model calls)."""
from __future__ import annotations

import json
import os
import shutil
import signal
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "evigate" / "poclib"))

import evigate_poc as P  # noqa: E402
from evigate import envbuild, rule  # noqa: E402
from evigate.agents import ScriptedAgent  # noqa: E402
from evigate.pipeline import Settings, verify  # noqa: E402
from evigate.sandbox import Sandbox  # noqa: E402
from evigate.workspace import copy_clean  # noqa: E402

FIX = ROOT / "tests" / "fixtures"


# ---------------------------------------------------------------- PoC helpers
def _sleep():
    time.sleep(30)


def _hog():
    return bytearray(4 * 1024 ** 3)


def _segv():
    os.kill(os.getpid(), signal.SIGSEGV)


def _boom():
    raise ValueError("rejected")


def test_run_isolated_classifies_outcomes():
    assert P.run_isolated(lambda: 41 + 1).status == "returned"
    r = P.run_isolated(_boom)
    assert (r.status, r.exc_type) == ("raised", "ValueError")
    assert P.run_isolated(_sleep, timeout_s=1).status == "timeout"
    assert P.run_isolated(_hog, memory_mb=256).status == "memory"
    c = P.run_isolated(_segv)
    assert c.status == "crashed" and c.signal == signal.SIGSEGV


def test_assert_bounded_and_canary():
    P.assert_bounded(P.run_isolated(_boom))            # a clean rejection is safe
    with pytest.raises(P.AttackSucceeded):
        P.assert_bounded(P.run_isolated(_sleep, timeout_s=1))
    can = P.Canary()
    can.assert_not_triggered()
    os.system(can.shell_payload)
    with pytest.raises(AssertionError):
        can.assert_not_triggered()
    with pytest.raises(AssertionError):
        P.assert_not_reflected("<p><script>x</script></p>", "<script>x</script>")


# ---------------------------------------------------------------- metadata and workspace
@pytest.mark.parametrize("spec,ver,ok", [
    (">=3.8", (3, 11), True), (">=3.8,<3.11", (3, 11), False), ("~=3.9", (3, 12), True),
    ("!=3.0.*,!=3.1.*,>=2.7", (3, 10), True), ("<3.10", (3, 10), False), (">3.9", (3, 9), False),
    ("", (3, 13), True)])
def test_spec_allows(spec, ver, ok):
    assert envbuild.spec_allows(ver, spec) is ok


def test_detect_python_prefers_classifiers():
    v, why = envbuild.detect_python(FIX / "toyshell")
    assert v == "3.13", why


def test_venv_ready_accepts_container_only_symlinks(tmp_path):
    (tmp_path / ".venv" / "bin").mkdir(parents=True)
    assert not envbuild.venv_ready(tmp_path)
    os.symlink("/opt/uvpython/cpython-3.11/bin/python3.11", tmp_path / ".venv" / "bin" / "python")
    assert envbuild.venv_ready(tmp_path)          # dangling on the host, valid inside the container


def test_clean_constraints_drops_the_project_itself():
    text = "-e /home/u/ws/vulnerable\nfoo==1.0\nbar @ file:///tmp/bar\nbaz @ https://x/y.whl\nqux==2\n# c\n"
    assert envbuild.clean_constraints(text) == "foo==1.0\nqux==2\n"


def test_copy_clean(tmp_path):
    src = tmp_path / "src"
    (src / ".git").mkdir(parents=True)
    (src / ".git" / "HEAD").write_text("x")
    (src / "venv").mkdir()
    (src / "venv" / "pyvenv.cfg").write_text("home=/x")
    (src / "pkg").mkdir()
    (src / "pkg" / "m.py").write_text("x = 1")
    outside = tmp_path / "secret.txt"
    outside.write_text("do not copy")
    os.symlink(outside, src / "pkg" / "leak.txt")
    os.symlink("m.py", src / "pkg" / "alias.py")
    stats = copy_clean(src, tmp_path / "dst")
    names = {str(p.relative_to(tmp_path / "dst")) for p in (tmp_path / "dst").rglob("*")}
    assert "pkg/m.py" in names and "pkg/alias.py" in names
    assert not any(n.startswith((".git", "venv")) for n in names) and "pkg/leak.txt" not in names
    assert stats["dropped_links"] == 1


# ---------------------------------------------------------------- the rule, end to end (local backend)
SCENARIOS = [
    ("full", "correct", "verified", 1),
    ("full", "incomplete", "not_blocked", 0),
    ("primary_only", "incomplete", "bypass", 0),
    ("primary_only", "correct", "verified", 1),
    ("full", "broken", "regression", 0),
    ("full", "bad", "patch_does_not_apply", 0),
    ("none", "correct", "not_reproduced", 0),
]


@pytest.mark.parametrize("attacker,patch,status,claim", SCENARIOS)
def test_verify_scenarios(tmp_path, attacker, patch, status, claim):
    os.environ["EVIGATE_LOCAL_HOME"] = str(tmp_path / "home")
    sbx = Sandbox("local")
    st = Settings(python="3.13", cache_dir=tmp_path / "cache", poc_timeout_s=120, baseline_timeout_s=120)
    state = verify(FIX / "toyshell", "toyshell lets a caller run shell commands through host names.",
                   (FIX / "patches" / f"{patch}.diff").read_text(), tmp_path / "case",
                   ScriptedAgent(FIX / "attackers" / attacker), sbx, st=st)
    v = state["verdict"]
    assert (v["status"], v["claim"]) == (status, claim), json.dumps(state["steps"], indent=1)[:3000]
    assert (tmp_path / "case" / "verdict.json").exists() and (tmp_path / "case" / "MANIFEST.sha256").exists()
    if attacker == "full" and patch != "bad":
        poc = state["steps"]["poc_vulnerable"]
        assert poc["counts"].get("INVALID", 0) >= 1          # the broken test is seen and ignored
        assert len(poc["reproduced"]) == 2


def test_verify_with_user_recipe(tmp_path):
    """A user build recipe replaces the automatic install; a failing line is logged and the build goes on."""
    os.environ["EVIGATE_LOCAL_HOME"] = str(tmp_path / "home")
    recipe = "python -m pip install -U pip\nthis-command-does-not-exist --flag\npython -m pip install -e .\n"
    st = Settings(python="3.13", cache_dir=tmp_path / "cache", poc_timeout_s=120, baseline_timeout_s=120,
                  setup_script=recipe, test_args=("-k", "ping or lookup"))
    state = verify(FIX / "toyshell", "toyshell lets a caller run shell commands through host names.",
                   (FIX / "patches" / "correct.diff").read_text(), tmp_path / "case",
                   ScriptedAgent(FIX / "attackers" / "full"), Sandbox("local"), st=st)
    env = state["steps"]["env"]
    assert env["ok"] and env["recipe"] == "user setup script" and env["installed_editable"], env
    assert "setup command failed" in (tmp_path / "case" / "logs" / "env_setup.log").read_text()
    assert state["verdict"]["status"] == "verified", state["verdict"]
