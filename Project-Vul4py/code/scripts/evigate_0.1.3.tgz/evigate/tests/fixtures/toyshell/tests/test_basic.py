from toyshell import lookup, ping


def test_ping():
    assert "ping example.com" in ping("example.com")


def test_lookup():
    assert "lookup example.com" in lookup("example.com")
