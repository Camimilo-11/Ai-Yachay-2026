"""A tiny network helper with a command injection (for evigate's own tests)."""
import subprocess


def ping(host):
    return subprocess.run(f"echo ping {host}", shell=True, capture_output=True, text=True).stdout


def lookup(host):
    return subprocess.run(f"echo lookup {host}", shell=True, capture_output=True, text=True).stdout
