from evigate_poc import Canary
from toyshell import ping


def test_ping_does_not_run_injected_command():
    c = Canary()
    ping("example.com; " + c.shell_payload)
    c.assert_not_triggered("ping()")
