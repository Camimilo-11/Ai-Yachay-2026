import toyshell_does_not_exist  # an INVALID test: must never count as evidence


def test_never_runs():
    assert False
