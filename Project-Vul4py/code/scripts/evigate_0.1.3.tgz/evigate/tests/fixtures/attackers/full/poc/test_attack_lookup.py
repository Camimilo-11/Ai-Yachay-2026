from evigate_poc import Canary
from toyshell import lookup


def test_lookup_does_not_run_injected_command():
    c = Canary()
    lookup("example.com && " + c.shell_payload)
    c.assert_not_triggered("lookup()")
