# Entrega de interfaz — Project-safe-wireless, 30-10-2026

## Cambios

La ampliación Sionna/CSI conserva Polyscope, ImGui, ImPlot y los contratos del motor. La ventana organiza la escena, los controles de simulación, datos reales y resultados en paneles compactos, con fondo oscuro y una cuadrícula geométrica de un metro. Los actores siguen etiquetados como colocados para simulación.

Se conservan edición de cinco actores, coordenadas/giro/escala/gizmo, paredes, TX/RX, frecuencia, ancho de banda, potencia, ruido, cálculo y cancelación Sionna, mapas, rayos, CIR, CFR, exportación, proyectos, sesiones y captura RSSI. La gráfica de una sesión guardada ahora muestra «REPRODUCCION» junto a la fuente original.

«Datos reales» separa RSSI de Windows de CSI ESP32. CSI admite selección de un modelo JSON numérico, archivo CSV observado y referencia vacía, llama la CLI existente en un proceso aparte y mantiene utilizable el visor. El resultado muestra calidad, ventanas aceptadas, rechazos, hashes, scores sin calibrar y predicciones. Un resultado negativo no se presenta como garantía de ausencia. La GUI no inicia captura CSI ni flashea el ESP32.

«Resultados» conserva las procedencias simulada, RSSI y CSI. Incluye el resumen del piloto y acceso a la demo académica V1. La demo sigue describiendo nueve escenarios sintéticos, no detecciones reales. Los dos campos de investigación permanecen nulos.

## Archivos de interfaz

- `src/safe_wirreles/desktop_ui.py`
- `src/safe_wirreles/ui_theme.py` (nuevo)

El paquete también contiene el diff, este informe y capturas creadas por la aplicación. La carpeta canónica `Project-safe-wireless` no se modificó. No se incluyeron `.venv`, `.runtime`, CSV crudos, manifiestos privados, contraseñas ni firmware.

## Verificación ejecutada

- `.venv/Scripts/python.exe -m safe_wirreles --diagnose`: correcto; Polyscope 2.6.1, Sionna RT 1.2.2 y LLVM local encontrados.
- `.venv/Scripts/python.exe -m pytest -q`: 393 pruebas y 33 subpruebas aprobadas.
- `.venv/Scripts/python.exe -m ruff check src tests scripts`: correcto.
- `.venv/Scripts/python.exe -m build --no-isolation`: sdist y wheel creados.
- Inicio y cálculo con Sionna: correcto; 47 caminos calculados y exportación NPZ.
- Edición de actor invalida el resultado anterior; guardar/abrir proyecto, cancelar cálculo y reproducir sesión comprobados.
- Captura RSSI de Windows: 4 observaciones; sin error. La sesión se reprodujo y etiquetó como tal.
- CSI por archivo: 14 ventanas aceptadas; calidad, hashes, predicciones y scores coinciden con la CLI para la misma entrada. Cuatro comprobaciones del puente pasaron: entradas faltantes, ejecución no bloqueante/rutas congeladas, rechazo de modelo JSON inválido y cierre del proceso hijo.
- Ventanas gráficas comprobadas: 1440 × 960 y 1280 × 720 con escala 125%.
- Las capturas de estado inicial y posterior a Sionna/CSI proceden de la aplicación nativa, con su interfaz visible.

## Límites

La inferencia de CSI requiere una captura y calibración existentes. En esta sesión se comprobó con el CSV de la campaña local; no se confirmó disponibilidad actual del ESP32 por puerto serie. El piloto corresponde a una campaña y tres rondas; sus métricas siguen siendo preliminares y no prueban generalización ni superioridad frente a RSSI/RTI.

## Cómo abrir

Desde la raíz de esta copia de `safe-wirreles`, ejecuta `run.ps1` o `Abrir safe-wirreles.vbs`. Para repetir el cálculo de humo: `run.ps1 --precompute --frames 10 --screenshot output/ui-astra/captura.png`.
