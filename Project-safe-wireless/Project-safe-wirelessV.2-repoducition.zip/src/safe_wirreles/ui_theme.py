"""Shared presentation tokens for the native scientific workspace.

Colors express interface state only; a green control never denotes a detected
person. Use a text label alongside every status color.
"""

# Polyscope interprets its viewport background as linear light, then displays
# it through the framebuffer transfer curve. Convert the intended #0b1018 UI
# color back to linear values so the rendered viewport matches ImGui panels.
BACKGROUND = (0.00335, 0.00518, 0.00913)
SURFACE = (18 / 255, 27 / 255, 39 / 255, 1.0)
TEXT = (237 / 255, 243 / 255, 250 / 255, 1.0)
MUTED = (165 / 255, 184 / 255, 205 / 255, 1.0)
ACCENT = (102 / 255, 185 / 255, 255 / 255, 1.0)
SUCCESS = (106 / 255, 218 / 255, 177 / 255, 1.0)
WARNING = (246 / 255, 200 / 255, 112 / 255, 1.0)
ERROR = (255 / 255, 149 / 255, 149 / 255, 1.0)
CONTROL_BORDER = (113 / 255, 138 / 255, 165 / 255, 1.0)


def apply_style(ui):
    """Configure the installed Polyscope ImGui style after context creation."""
    style = ui.GetStyle()
    style.WindowPadding = (12.0, 10.0)
    style.FramePadding = (8.0, 5.0)
    style.ItemSpacing = (8.0, 7.0)
    style.ItemInnerSpacing = (6.0, 5.0)
    style.WindowRounding = 5.0
    style.FrameRounding = 3.0
    style.GrabRounding = 3.0
    style.WindowBorderSize = 0.0
    style.FrameBorderSize = 1.0
    style.ScrollbarSize = 13.0
    style.ScrollbarRounding = 3.0
    style.GrabMinSize = 14.0
    colors = {
        ui.ImGuiCol_WindowBg: SURFACE,
        ui.ImGuiCol_ChildBg: SURFACE,
        ui.ImGuiCol_PopupBg: (0.08, 0.12, 0.17, 1.0),
        ui.ImGuiCol_Text: TEXT,
        ui.ImGuiCol_TextDisabled: MUTED,
        ui.ImGuiCol_Border: CONTROL_BORDER,
        ui.ImGuiCol_FrameBg: (0.08, 0.13, 0.19, 1.0),
        ui.ImGuiCol_FrameBgHovered: (0.11, 0.18, 0.27, 1.0),
        ui.ImGuiCol_FrameBgActive: (0.12, 0.21, 0.31, 1.0),
        ui.ImGuiCol_Button: (0.10, 0.23, 0.37, 1.0),
        ui.ImGuiCol_ButtonHovered: (0.14, 0.30, 0.47, 1.0),
        ui.ImGuiCol_ButtonActive: (0.12, 0.27, 0.43, 1.0),
        ui.ImGuiCol_Header: (0.09, 0.17, 0.25, 1.0),
        ui.ImGuiCol_HeaderHovered: (0.12, 0.24, 0.36, 1.0),
        ui.ImGuiCol_HeaderActive: (0.14, 0.28, 0.41, 1.0),
        ui.ImGuiCol_CheckMark: ACCENT,
        ui.ImGuiCol_SliderGrab: ACCENT,
        ui.ImGuiCol_SliderGrabActive: TEXT,
        ui.ImGuiCol_Tab: (0.075, 0.12, 0.18, 1.0),
        ui.ImGuiCol_TabHovered: (0.14, 0.27, 0.40, 1.0),
        ui.ImGuiCol_TabSelected: (0.11, 0.22, 0.34, 1.0),
        ui.ImGuiCol_TabSelectedOverline: ACCENT,
        ui.ImGuiCol_TitleBg: (*BACKGROUND, 1.0),
        ui.ImGuiCol_TitleBgActive: (0.09, 0.15, 0.22, 1.0),
        ui.ImGuiCol_Separator: (0.18, 0.25, 0.34, 1.0),
        ui.ImGuiCol_SeparatorHovered: ACCENT,
        ui.ImGuiCol_SeparatorActive: ACCENT,
        ui.ImGuiCol_ScrollbarBg: (*BACKGROUND, 1.0),
        ui.ImGuiCol_ScrollbarGrab: CONTROL_BORDER,
        ui.ImGuiCol_ScrollbarGrabHovered: MUTED,
        ui.ImGuiCol_ScrollbarGrabActive: ACCENT,
        ui.ImGuiCol_NavCursor: ACCENT,
        ui.ImGuiCol_TextSelectedBg: (0.15, 0.37, 0.58, 0.8),
        ui.ImGuiCol_TableHeaderBg: (0.10, 0.18, 0.26, 1.0),
        ui.ImGuiCol_TableBorderStrong: (0.24, 0.32, 0.42, 1.0),
        ui.ImGuiCol_TableBorderLight: (0.16, 0.23, 0.31, 1.0),
        ui.ImGuiCol_TableRowBgAlt: (0.09, 0.14, 0.20, 1.0),
    }
    for index, color in colors.items():
        style.Colors[index] = color
