"""Native scientific viewer using Polyscope, Dear ImGui and ImPlot.

UI/worker separation is original to safe-wirreles. Interaction follows the
official Sionna RT GUI and Polyscope's documented callback lifecycle:
https://github.com/NVlabs/sionna-rt-gui
https://polyscope.run/py/basics/interactive_UIs_and_animation/
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import time
import webbrowser
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

import numpy as np

from .desktop_model import observation_series, pack_paths, radio_map_mesh
from .runtime import project_root
from .ui_theme import ACCENT, BACKGROUND, ERROR, MUTED, WARNING, apply_style

LABELS = {"human": "Humano", "cat": "Gato", "dog": "Perro"}
COLORS = {"human": (0.24, 0.66, 0.92), "cat": (0.94, 0.68, 0.30),
          "dog": (0.66, 0.50, 0.89)}


class Desktop:
    def __init__(self, controller):
        import polyscope as ps
        import polyscope.imgui as ui
        import polyscope.implot as plot

        self.ps, self.ui, self.plot = ps, ui, plot
        self.controller = controller
        self.selected_id: str | None = None
        self.mesh_names: set[str] = set()
        self.scene_signature = None
        self.result_identity = None
        self.show_walls = False
        self.show_paths = True
        self.show_map = False
        self.gizmo_enabled = False
        self.gizmo = None
        self.gizmo_actor_id = None
        self.gizmo_last_position = None
        self.message = ""
        self.message_is_error = False
        self.project_path = "experiments/project.json"
        self.session_path = "experiments/session.json"
        self.simulation_path = "experiments/simulation.npz"
        self.signal_view = 0
        self.plot_link_id = None
        self.panel_view = 0
        self.real_view = 0
        self.csi_inputs = {"model": "", "observed": "", "calibration": ""}
        self.csi_process = None
        self.csi_log = None
        self.csi_result = None
        self.csi_error = ""
        self.csi_output = None
        self.csi_snapshot = {}
        self.csi_started = 0.0
        self.csi_page = 0
        self.plot_height = 160
        self.v1_path = self.find_v1_demo()

    @staticmethod
    def find_v1_demo():
        candidates = [project_root() / "demo/index.html",
                      project_root().parent.parent / "demo/index.html",
                      Path.home() / "Documents/GitHub/Ai-Yachay-2026/Project-safe-wireless/demo/index.html"]
        return next((p.resolve() for p in candidates if p.is_file()), None)

    def action(self, function: Callable, *args, success: str = ""):
        try:
            result = function(*args)
            self.message, self.message_is_error = success, False
            return result
        except (OSError, ValueError, RuntimeError, TypeError) as exc:
            self.message, self.message_is_error = str(exc), True
            return None

    def update(self, target: Any, name: str, value: Any):
        previous = getattr(target, name)
        setattr(target, name, value)
        try:
            self.controller.scene.validate()
            self.controller.scene_changed()
        except (ValueError, TypeError) as exc:
            setattr(target, name, previous)
            self.message, self.message_is_error = str(exc), True

    def setup(self):
        ps = self.ps
        ps.set_program_name("Project-safe-wireless | Sionna / CSI")
        ps.set_use_prefs_file(False)
        ps.set_build_default_gui_panels(False)
        ps.set_open_imgui_window_for_user_callback(False)
        ps.set_window_size(1440, 960)
        ps.set_ui_scale(1.0)
        ps.set_configure_imgui_style_callback(self.style)
        ps.init()
        ps.set_up_dir("z_up")
        ps.set_ground_plane_mode("none")
        ps.set_background_color(BACKGROUND)
        ps.set_navigation_style("turntable")
        ps.set_transparency_mode("pretty")
        ps.set_automatically_compute_scene_extents(False)
        ps.set_length_scale(10.0)
        ps.set_bounding_box((0, 0, 0), tuple(self.controller.scene.room_size))
        ps.set_max_fps(30)
        ps.set_frame_tick_limit_fps_mode("block_to_hit_target")
        self.sync_scene()
        self.reset_camera()
        ps.set_user_callback(self.callback)

    def style(self):
        apply_style(self.ui)

    def reset_camera(self):
        x, y, z = self.controller.scene.room_size
        self.ps.look_at((x * 1.48, -y * 1.22, z * 3.2), (x / 2, y / 2, z * 0.2))

    def sync_scene(self):
        from .propagation import scene_geometry

        scene = self.controller.scene
        signature = repr(scene.to_dict()) + str(self.show_walls)
        if signature == self.scene_signature:
            return
        self.scene_signature = signature
        geometry = scene_geometry(scene)
        current = set()
        for name, item in geometry.items():
            key = "scene/" + name
            current.add(key)
            is_room = item.get("kind") == "room"
            color = COLORS.get(item.get("kind"), item.get("color", (0.34, 0.40, 0.47)))
            if is_room:
                color = (0.018, 0.028, 0.042) if name == "floor" else (0.025, 0.038, 0.055)
            mesh = self.ps.register_surface_mesh(key, item["vertices"], item["faces"],
                                                  color=color, smooth_shade=not is_room)
            mesh.set_transparency(float(item.get("alpha", 1.0)))
            if is_room:
                mesh.set_enabled(name != "ceiling" and (self.show_walls or name not in {"wall_x1", "wall_y0"}))
            mesh.set_selection_mode("faces_only")
        for old in self.mesh_names - current:
            self.ps.remove_surface_mesh(old, error_if_absent=False)
        self.mesh_names = current
        # A one-metre ruler on the simulated floor; never an inferred presence map.
        x, y, _ = scene.room_size
        grid_nodes, grid_edges = [], []
        for axis, limit in ((0, x), (1, y)):
            for value in np.arange(0, min(limit, 100) + .01, 1):
                pair = ((value, 0, .015), (value, y, .015)) if axis == 0 else ((0, value, .015), (x, value, .015))
                grid_edges.append((len(grid_nodes), len(grid_nodes) + 1))
                grid_nodes.extend(pair)
        grid = self.ps.register_curve_network("Regla de suelo / 1 m", np.asarray(grid_nodes),
                                              np.asarray(grid_edges), color=(.08, .15, .22))
        grid.set_radius(.006, relative=False)
        for label, position, color in [
            ("TX · transmisor", scene.tx_position, (0.27, 0.89, 0.66)),
            ("RX · receptor", scene.rx_position, (1.0, 0.46, 0.38)),
        ]:
            point = self.ps.register_point_cloud(label, np.asarray([position]), color=color)
            point.set_radius(0.13, relative=False)

    def sync_result(self):
        result = self.current_result()
        identity = (id(result), self.show_paths, self.show_map)
        if identity == self.result_identity:
            return
        self.result_identity = identity
        self.ps.remove_curve_network("Propagación calculada", error_if_absent=False)
        self.ps.remove_surface_mesh("Mapa de potencia", error_if_absent=False)
        if result is None:
            return
        nodes, edges = pack_paths(result.get("paths", []))
        if len(edges):
            rays = self.ps.register_curve_network("Propagación calculada", nodes, edges,
                                                 color=(0.33, 0.88, 0.84), enabled=self.show_paths)
            rays.set_radius(0.009, relative=False)
        radio_map = result.get("radio_map")
        if radio_map is not None:
            vertices, faces, values = radio_map_mesh(radio_map)
            if len(faces):
                mesh = self.ps.register_surface_mesh("Mapa de potencia", vertices, faces, enabled=self.show_map)
                mesh.add_scalar_quantity("Potencia recibida (dBm)", values, defined_on="faces", enabled=True,
                                         cmap="viridis")

    def current_result(self):
        result = self.controller.result
        if result is not None and result.get("revision", self.controller.scene.revision) != self.controller.scene.revision:
            return None
        return result

    def window(self, name: str, position, size):
        ui = self.ui
        ui.SetNextWindowPos(position, ui.ImGuiCond_Always)
        ui.SetNextWindowSize(size, ui.ImGuiCond_Always)
        flags = (ui.ImGuiWindowFlags_NoMove | ui.ImGuiWindowFlags_NoResize |
                 ui.ImGuiWindowFlags_NoCollapse | ui.ImGuiWindowFlags_NoSavedSettings)
        return ui.Begin(name, flags=flags)

    def section(self, title, default_open=False):
        flags = self.ui.ImGuiTreeNodeFlags_DefaultOpen if default_open else 0
        return self.ui.CollapsingHeader(title, flags)

    def callback(self):
        self.controller.poll()
        self.poll_csi()
        self.sync_scene()
        self.sync_result()
        # ImGui uses logical display coordinates; this also accounts for DPI scaling.
        width, height = self.ui.GetIO().DisplaySize
        left = min(276, max(232, width * 0.19))
        right = min(328, max(282, width * 0.225))
        middle = max(160, width - left - right - 40)
        top = 88
        bottom = min(234, max(190, height * .25))
        ui, c = self.ui, self.controller

        self.window("Project-safe-wireless  /  Sionna + CSI", (10, 8), (width - 20, 70))
        ui.TextColored(ACCENT, "LABORATORIO WI-FI")
        ui.SameLine()
        ui.TextUnformatted("Simulacion fisica y observaciones del entorno")
        ui.End()

        self.window("01 / Escena", (10, top), (left, height - top - 10))
        ui.PushItemWidth(-90)
        self.scene_panel()
        ui.PopItemWidth()
        ui.End()

        self.window("02 / Experimento", (width - right - 10, top), (right, height - top - 10))
        ui.PushItemWidth(-90)
        self.control_panel()
        ui.PopItemWidth()
        ui.End()

        self.window("SIMULACION / actores colocados", (left + 20, top), (middle, 112))
        ui.TextUnformatted(f"{c.scene.frequency_hz / 1e9:.3f} GHz  |  {len(c.scene.actors)}/5 actores  |  Escala: metros")
        if ui.Button("Centrar"):
            self.reset_camera()
        ui.SameLine()
        _, self.show_paths = ui.Checkbox("Rayos", self.show_paths)
        ui.SameLine()
        _, self.show_map = ui.Checkbox("Mapa", self.show_map)
        ui.End()

        self.window("03 / Senales y canal", (left + 20, height - bottom - 10), (middle, bottom))
        self.plot_height = max(90, bottom - 103)
        self.signal_panel()
        ui.End()
        self.update_gizmo()

    def scene_panel(self):
        ui, controller = self.ui, self.controller
        ui.TextColored(ACCENT, f"ACTORES    {len(controller.scene.actors)} / 5")
        ui.TextWrapped("Geometrias de simulacion. Selecciona un actor para editarlo.")
        ui.BeginDisabled(len(controller.scene.actors) >= 5)
        for index, (kind, label) in enumerate(LABELS.items()):
            if index:
                ui.SameLine()
            if ui.Button("+ " + label):
                self.action(controller.add_actor, kind)
                if controller.scene.actors:
                    self.selected_id = controller.scene.actors[-1].actor_id
        ui.EndDisabled()
        ui.Separator()
        if not controller.scene.actors:
            ui.TextColored(MUTED, "Añade un humano, un gato o un perro.")
        for actor in controller.scene.actors:
            selected = actor.actor_id == self.selected_id
            clicked = ui.Selectable(f"{LABELS[actor.kind]}  ·  {actor.actor_id}", selected)
            if (clicked[0] if isinstance(clicked, tuple) else clicked):
                self.selected_id = actor.actor_id
        actor = next((a for a in controller.scene.actors if a.actor_id == self.selected_id), None)
        if actor:
            ui.Separator()
            ui.TextUnformatted("Posición de pies/patas (metros)")
            coordinates = list(actor.position)
            for i, axis in enumerate("XYZ"):
                changed, value = ui.SliderFloat(axis, coordinates[i], 0.0, float(controller.scene.room_size[i]), "%.2f m")
                if changed:
                    coordinates[i] = value
                    self.update(actor, "position", tuple(coordinates))
            changed, value = ui.SliderFloat("Giro", float(actor.yaw_deg), -180, 180, "%.0f grados")
            if changed:
                self.update(actor, "yaw_deg", value)
            changed, value = ui.SliderFloat("Escala", float(actor.scale), 0.4, 1.8, "%.2f")
            if changed:
                self.update(actor, "scale", value)
            _, self.gizmo_enabled = ui.Checkbox("Mover con control 3D", self.gizmo_enabled)
            if ui.Button("Eliminar actor seleccionado"):
                self.action(controller.remove_actor, actor.actor_id)
                self.selected_id = None
        ui.Separator()
        if self.section("Entorno"):
            x, y, z = controller.scene.room_size
            ui.TextUnformatted(f"Salón: {x:.1f} × {y:.1f} × {z:.1f} m")
            ui.TextWrapped("Sala de ejemplo ficticia; no representa un plano medido.")
            _, self.show_walls = ui.Checkbox("Ver todas las paredes", self.show_walls)
            ui.TextColored(MUTED, "TX verde  ·  RX coral")
            ui.TextWrapped("Camara: arrastrar para girar, rueda para zoom, boton derecho para desplazar.")
        if self.section("Proyecto y sesiones"):
            ui.TextUnformatted("Proyecto JSON")
            ui.SetNextItemWidth(-1)
            _, self.project_path = ui.InputText("##project", self.project_path)
            if ui.Button("Guardar proyecto"):
                self.action(controller.save_project, self.project_path, success="Proyecto guardado.")
            if ui.Button("Abrir proyecto"):
                self.action(controller.load_project, self.project_path, success="Proyecto abierto.")
                self.selected_id = None
            ui.SetNextItemWidth(-1)
            _, self.session_path = ui.InputText("##session", self.session_path)
            ui.BeginDisabled(bool(getattr(controller, "observations_dropped", 0)))
            if ui.Button("Guardar observaciones"):
                self.action(controller.save_session, self.session_path, success="Observaciones guardadas.")
            ui.EndDisabled()
            if ui.Button("Reproducir archivo"):
                self.action(controller.load_session, self.session_path, success="Sesión cargada como reproducción.")
            ui.SetNextItemWidth(-1)
            _, self.simulation_path = ui.InputText("##simulation-file", self.simulation_path)
            ui.BeginDisabled(self.current_result() is None)
            if ui.Button("Exportar cálculo NPZ"):
                self.action(controller.export_simulation, self.simulation_path, success="Cálculo exportado.")
            ui.EndDisabled()
            ui.TextWrapped("Elige rutas distintas para conservar experimentos anteriores.")
        if self.section("Investigacion V1"):
            self.v1_panel()
        if self.message:
            ui.Separator()
            ui.TextColored(ERROR if self.message_is_error else ACCENT, "Aviso")
            ui.TextWrapped(self.message)

    def control_panel(self):
        ui, c = self.ui, self.controller
        ui.TextColored(ACCENT, "SIONNA RT / SIMULACION")
        busy = c.simulation_status == "running"
        if busy:
            if ui.Button("Cancelar calculo", (-1, 32)):
                self.action(c.cancel_simulation)
        elif ui.Button("Calcular propagacion", (-1, 34)):
            self.action(c.start_simulation)
        ui.TextWrapped("Estado: " + self.status_label(c.simulation_status))
        if c.simulation_error:
            ui.TextColored(ERROR, "Error de simulacion")
            ui.TextWrapped(str(c.simulation_error))
        ui.Separator()
        ui.SetNextItemWidth(-1)
        _, self.panel_view = ui.Combo("##experiment-view", self.panel_view,
                                     ["Simulacion", "Datos reales", "Resultados"])
        if self.panel_view == 0:
            self.simulation_panel()
        elif self.panel_view == 1:
            ui.SetNextItemWidth(-1)
            _, self.real_view = ui.Combo("##real-source", self.real_view,
                                         ["RSSI / adaptador Windows", "CSI / archivo ESP32"])
            if self.real_view == 0:
                self.rssi_panel()
            else:
                self.csi_panel()
        else:
            self.results_panel()

    def simulation_panel(self):
        ui, c = self.ui, self.controller
        if self.section("Radio y condiciones", True):
            scene = c.scene
            bands = [2.437e9, 5.18e9, 6.115e9]
            band = min(range(3), key=lambda i: abs(bands[i]-scene.frequency_hz))
            changed, band = ui.Combo("Banda", band, ["2,4 GHz", "5 GHz", "6 GHz"])
            if changed:
                self.update(scene, "frequency_hz", bands[band])
            ui.TextUnformatted("Frecuencia central (GHz)")
            ui.SetNextItemWidth(-1)
            changed, value = ui.InputDouble("##central-frequency", scene.frequency_hz/1e9, 0.001, 0.02, "%.3f")
            if changed:
                self.update(scene, "frequency_hz", value*1e9)
            if hasattr(scene, "bandwidth_hz"):
                changed, value = ui.Combo("Ancho", [20e6, 40e6, 80e6].index(scene.bandwidth_hz) if scene.bandwidth_hz in [20e6, 40e6, 80e6] else 0,
                                          ["20 MHz", "40 MHz", "80 MHz"])
                if changed:
                    self.update(scene, "bandwidth_hz", [20e6, 40e6, 80e6][value])
            changed, value = ui.SliderFloat("TX (dBm)", float(scene.tx_power_dbm), -10, 30, "%.1f")
            if changed:
                self.update(scene, "tx_power_dbm", value)
            changed, value = ui.SliderFloat("Ruido (dBm)", float(scene.noise_dbm), -120, -40, "%.1f")
            if changed:
                self.update(scene, "noise_dbm", value)
            ui.TextWrapped("Ruido receptor configurable. Las reflexiones dependen de los objetos; la interferencia de otros emisores requiere un modelo aparte.")
            if self.section("Posición de TX / RX"):
                for field, label in [("tx_position", "TX"), ("rx_position", "RX")]:
                    coords = list(getattr(scene, field))
                    for i, axis in enumerate("XYZ"):
                        changed, value = ui.SliderFloat(f"{label} {axis}", coords[i], 0.05, float(scene.room_size[i])-0.05, "%.2f m")
                        if changed:
                            coords[i] = value
                            self.update(scene, field, tuple(coords))

        if self.section("Parametro de investigacion"):
            ui.TextUnformatted("parametro_investigacion: null")
            ui.TextUnformatted("valor_estimado: null")
            ui.TextColored(MUTED, "Pendiente de definir")

    def rssi_panel(self):
        ui, c = self.ui, self.controller
        mode = "REPRODUCCION" if c.capture_status == "replay" else "REAL / RSSI WINDOWS"
        if c.capture_status == "simulated":
            mode = "SIMULACION / OBSERVACIONES"
        ui.TextColored(ACCENT, mode)
        if not c.observations:
            ui.TextColored(WARNING, "SIN DATOS")
        if self.section("Wi-Fi real", True):
            ui.TextWrapped("RSSI del adaptador local. La consulta puede devolver lecturas en caché.")
            if ui.Button("Iniciar captura"):
                self.action(c.start_capture)
            ui.SameLine()
            if ui.Button("Detener"):
                self.action(c.stop_capture)
            ui.TextWrapped("Captura: " + self.status_label(c.capture_status))
            ui.TextUnformatted(f"Observaciones en memoria: {len(c.observations)}")
            if getattr(c, "observations_dropped", 0):
                ui.TextColored(ERROR, "Memoria llena; inicia una sesión nueva.")
                ui.TextWrapped(f"Lecturas anteriores fuera de memoria: {c.observations_dropped}. Calibración conservada; guardado completo no disponible.")
            if c.capture_error:
                ui.TextColored(ERROR, "Captura no disponible")
                ui.TextWrapped(str(c.capture_error))
        if self.section("Cambio de senal experimental", True):
            detection = c.detection or {}
            state = detection.get("state")
            presence = {"insufficient_data": "Esperando lecturas suficientes",
                        "change_detected": "Cambio de señal detectado",
                        "no_change": "Sin cambio significativo"}.get(state,
                        detection.get("presence", detection.get("status", "Sin datos")))
            if presence is True:
                presence = "Cambio compatible con presencia"
            elif presence is False:
                presence = "Sin cambio significativo"
            elif presence is None:
                presence = "No disponible"
            ui.TextWrapped("Estado: " + str(presence))
            if detection.get("delta") is not None:
                ui.TextUnformatted(f"Cambio: {detection['delta']:+.2f} {detection.get('unit', '')}")
            ui.TextColored(MUTED, "Especie / conteo / posición: N/D")
            ui.TextWrapped("Referencia RSSI experimental; no identifica individuos ni animales.")

    def results_panel(self):
        ui = self.ui
        result = self.current_result()
        ui.TextColored(ACCENT, "SIONNA / ESCENA VIGENTE")
        if result is None:
            ui.TextWrapped("Sin calculo vigente. Calcula la propagacion para examinar el canal.")
        else:
            rssi = result.get("rssi_dbm")
            if rssi is not None:
                ui.TextUnformatted(f"Potencia RX: {float(np.asarray(rssi).reshape(-1)[0]):.1f} dBm")
            ui.TextUnformatted(f"Caminos: {len(result.get('paths', []))}")
            if self.show_map and result.get("radio_map") is not None:
                values = np.asarray(result["radio_map"]["values"], dtype=float)
                finite = values[np.isfinite(values)]
                if finite.size:
                    ui.TextWrapped(f"Mapa: {finite.min():.1f} a {finite.max():.1f} dBm; violeta a amarillo.")
            if self.section("Notas del calculo"):
                notes = result.get("model_notes", result.get("notes", []))
                for note in notes if isinstance(notes, list) else [notes]:
                    ui.TextWrapped(str(note))
                for note in result.get("observation_notes", []):
                    ui.TextWrapped(str(note))
        ui.Separator()
        ui.TextColored(ACCENT, "CSI ESP32 / PILOTO GUARDADO")
        ui.TextWrapped("30 octubre 2026 / evaluacion por ronda excluida")
        ui.TextUnformatted("Precision positiva        70,13 %")
        ui.TextUnformatted("Sensibilidad quieta       61,90 %")
        ui.TextUnformatted("Falsas alarmas en vacio    27,38 %")
        ui.TextWrapped("Una campana, tres rondas; 165 ventanas de dos segundos. Modelo todavia no fiable.")
        ui.TextWrapped("Estas metricas no evalúan los archivos que proceses desde la interfaz.")
        if self.section("Evidencia del piloto"):
            ui.TextWrapped("results/esp32/presence-model-20261030.md")
            ui.TextWrapped("Modelo binario; sin conteo, especies ni localizacion real.")
        ui.Separator()
        self.v1_panel()

    def v1_panel(self):
        ui = self.ui
        ui.TextColored(ACCENT, "DEMO ACADEMICA V1")
        ui.TextWrapped("RSS / RTI / EM / K-NN. Nueve escenarios sinteticos guardados, 30 consultas por escenario.")
        if self.v1_path is None:
            ui.TextWrapped("Demo V1 no disponible en esta copia.")
        elif ui.Button("Abrir demo V1", (-1, 30)):
            self.action(webbrowser.open, self.v1_path.as_uri())
        if self.v1_path is not None and self.section("Ruta de la demo"):
            ui.TextWrapped(str(self.v1_path))

    def signal_panel(self):
        ui = self.ui
        ui.SetNextItemWidth(180)
        _, self.signal_view = ui.Combo("Vista", self.signal_view, ["Observación", "CFR", "CIR"])
        [self.observation_plot, self.cfr_plot, self.cir_plot][self.signal_view]()

    def start_csi(self):
        if self.csi_process is not None:
            raise ValueError("Ya se esta procesando un archivo CSI.")
        self.csi_result, self.csi_error = None, ""
        paths = {key: Path(value).expanduser().resolve() for key, value in self.csi_inputs.items()}
        if any(not self.csi_inputs[key].strip() or not path.is_file() for key, path in paths.items()):
            raise ValueError("Selecciona modelo JSON, CSV observado y referencia vacia existentes.")
        root = project_root()
        script = root / "scripts/predict_esp32_presence.py"
        if not script.is_file():
            raise ValueError("La CLI de inferencia no esta incluida en esta copia.")
        output = root / "output/csi-ui" / (uuid4().hex + ".json")
        output.parent.mkdir(parents=True, exist_ok=True)
        command = [sys.executable, str(script)]
        for key, path in paths.items():
            command.extend(["--" + key, str(path)])
        command.extend(["--output", str(output)])
        log = tempfile.TemporaryFile(mode="w+b")
        try:
            process = subprocess.Popen(command, cwd=root, stdout=log, stderr=log,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError:
            log.close()
            raise
        self.csi_process, self.csi_log = process, log
        self.csi_output, self.csi_snapshot = output, {k: str(v) for k, v in paths.items()}
        self.csi_started, self.csi_page = time.monotonic(), 0

    def poll_csi(self):
        if self.csi_process is None:
            return
        code = self.csi_process.poll()
        if code is None:
            if time.monotonic() - self.csi_started > 120:
                self.close_csi()
                self.csi_error = "Tiempo limite de 120 s. Reduce la duracion del archivo y reintenta."
            return
        try:
            if code != 0:
                self.csi_log.seek(0)
                self.csi_error = self.csi_log.read(6000).decode("utf-8", errors="replace").strip()
                if not self.csi_error:
                    self.csi_error = f"La inferencia termino con codigo {code}."
                return
            if self.csi_output.stat().st_size > 20 * 1024 * 1024:
                raise ValueError("Salida superior a 20 MiB; consulta el archivo fuera del visor.")
            result = json.loads(self.csi_output.read_text(encoding="utf-8"))
            if (result.get("status") != "inference_only_not_validation"
                    or result.get("score_status") != "uncalibrated_forest_score"
                    or not isinstance(result.get("windows"), list) or not result["windows"]):
                raise ValueError("La salida no corresponde a la inferencia CSI esperada.")
            self.csi_result = result
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            self.csi_error = str(exc)
        finally:
            self.close_csi()

    def close_csi(self):
        process = self.csi_process
        try:
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
        finally:
            self.csi_process = None
            if self.csi_log is not None:
                self.csi_log.close()
                self.csi_log = None

    def csi_panel(self):
        ui = self.ui
        ui.TextColored(ACCENT, "REAL / ARCHIVO CSI ESP32")
        ui.TextWrapped("Prediccion experimental por ventana. Puerto serie: no comprobado; captura por CLI.")
        ui.BeginDisabled(self.csi_process is not None)
        for key, label in (("model", "Modelo numerico JSON"), ("observed", "CSV observado"),
                           ("calibration", "CSV de referencia vacia")):
            ui.TextUnformatted(label)
            ui.SetNextItemWidth(-1)
            _, self.csi_inputs[key] = ui.InputText("##csi-" + key, self.csi_inputs[key])
        if ui.Button("Procesar archivos", (-1, 32)):
            self.action(self.start_csi)
        ui.EndDisabled()
        if self.message_is_error and self.message:
            ui.TextColored(ERROR, "Revisa las entradas")
            ui.TextWrapped(self.message)
        if self.csi_process is not None:
            ui.TextColored(WARNING, "Procesando archivo...")
            ui.TextWrapped("El visor sigue disponible. Limite: 120 s.")
        elif self.csi_error:
            ui.TextColored(ERROR, "SIN RESULTADO UTILIZABLE")
            ui.TextWrapped(self.csi_error)
        elif self.csi_result is None:
            ui.TextColored(WARNING, "SIN DATOS PROCESADOS")
            ui.TextWrapped("Introduce rutas de archivos. Referencia: al menos 14 s y 100 paquetes seleccionados.")
        if self.csi_result is None:
            return
        result = self.csi_result
        quality = result["quality"]
        ui.Separator()
        ui.TextColored(ACCENT, "REPRODUCCION / INFERENCIA GUARDADA")
        ui.TextWrapped("Archivo: " + Path(self.csi_snapshot["observed"]).name)
        ui.TextWrapped(f"Soporte observado: {quality['observed']['duration_s']:.2f} s. Tiempos de ventana relativos al archivo.")
        ui.TextUnformatted(f"Aceptadas: {quality['windows_accepted']} / {quality['windows_candidate']}")
        ui.TextWrapped(f"Rechazadas por huecos: {quality['windows_rejected_gap']}; por cobertura: {quality['windows_rejected_coverage']}.")
        ui.TextWrapped("Score del bosque, sin calibracion estadistica (0 a 1). Umbral: 0,5. No valida exactitud.")
        windows = result["windows"]
        page_count = (len(windows) + 7) // 8
        self.csi_page = min(self.csi_page, page_count - 1)
        ui.BeginDisabled(self.csi_page == 0)
        if ui.SmallButton("Anterior"):
            self.csi_page -= 1
        ui.EndDisabled()
        ui.SameLine()
        ui.BeginDisabled(self.csi_page + 1 >= page_count)
        if ui.SmallButton("Siguiente"):
            self.csi_page += 1
        ui.EndDisabled()
        ui.SameLine()
        ui.TextUnformatted(f"{self.csi_page + 1}/{page_count}")
        for window in windows[self.csi_page * 8:(self.csi_page + 1) * 8]:
            label = "Positiva" if window['predicted_presence'] else "Negativa"
            ui.TextUnformatted(f"{window['start_s']:5.1f}-{window['end_s']:5.1f} s  {label}  {window['score_presence']:.3f}")
        ui.TextWrapped("Una prediccion negativa no garantiza ausencia. Los huecos no se clasifican.")
        if self.section("Archivos y procedencia"):
            for key, path in self.csi_snapshot.items():
                ui.TextWrapped(key + ": " + path)
            ui.TextWrapped("Salida: " + str(self.csi_output))
            for key, digest in result['source_hashes'].items():
                ui.TextWrapped(key + ": " + digest)

    def observation_plot(self):
        observations = self.controller.observations
        if observations:
            latest_source = getattr(observations[-1], "source", None)
            links = sorted({str(getattr(o, "link_id", "")) for o in observations
                            if getattr(o, "source", None) == latest_source})
            if self.plot_link_id not in links:
                self.plot_link_id = links[0] if links else None
            if len(links) > 1:
                self.ui.SetNextItemWidth(-1)
                _, index = self.ui.Combo("##signal-link", links.index(self.plot_link_id), links)
                self.plot_link_id = links[index]
        x, y, unit, link = observation_series(observations, self.plot_link_id)
        if len(y):
            source = getattr(self.controller.observations[-1], "source", "")
            provenance = "REPRODUCCION / " if self.controller.capture_status == "replay" else ""
            self.ui.TextUnformatted(f"{provenance}{source}  ·  {str(link)[:36]}")
            time_label = "Tiempo simulado (s)" if source == "SIMULATED" else "Tiempo de consulta relativo (s)"
            self.draw_plot("##observations", x, y, time_label, "RSSI ("+unit+")", "Observación")
        elif self.current_result() is not None:
            result = self.current_result()
            rssi = np.asarray(result.get("rssi_dbm", []), dtype=float).reshape(-1)
            times = np.asarray(result.get("times_s", []), dtype=float).reshape(-1)
            if len(rssi) == len(times) and len(times):
                self.ui.TextColored(MUTED, "SIMULACIÓN · potencia recibida calculada")
                self.draw_plot("##synthetic", times, rssi, "Tiempo (s)", "Potencia (dBm)", "RX")
            else:
                self.ui.TextWrapped("Sin secuencia temporal disponible. Consulta CIR o CFR.")
        else:
            self.ui.TextWrapped("Calcula una escena, inicia la captura real o abre una sesión guardada para ver observaciones.")
            self.ui.TextColored(MUTED, "No se generan lecturas ficticias cuando falta un dispositivo.")

    def cfr_plot(self):
        result = self.current_result()
        if result is None:
            self.ui.TextWrapped("Calcula la propagación para obtener la respuesta del canal.")
            return
        cfr = np.asarray(result.get("cfr", []))
        if not cfr.size:
            self.ui.TextUnformatted("CFR no disponible.")
            return
        values = np.abs(cfr.reshape(-1, cfr.shape[-1])[0])
        frequencies = np.asarray(result.get("subcarrier_hz", np.arange(len(values))), dtype=float).reshape(-1)
        if len(frequencies) != len(values):
            self.ui.TextUnformatted("Ejes CFR incompatibles; revisa los datos del cálculo.")
            return
        self.ui.TextColored(MUTED, "SIMULACIÓN · canal ideal sin normalizar")
        self.draw_plot("##cfr", frequencies / 1e6, values, "Desplazamiento de subportadora (MHz)", "|H|", "CFR · primer instante")

    def cir_plot(self):
        result = self.current_result()
        if result is None:
            self.ui.TextWrapped("La CIR muestra amplitud y retardo por camino calculado.")
            return
        amplitudes = np.abs(np.asarray(result.get("cir_amplitudes", [])))
        if amplitudes.ndim > 1:
            amplitudes = amplitudes[:, 0]
        amplitudes = amplitudes.reshape(-1)
        delays = np.asarray(result.get("delays_s", []), dtype=float).reshape(-1)
        if len(amplitudes) != len(delays) or not len(delays):
            self.ui.TextUnformatted("CIR no disponible.")
            return
        valid = np.isfinite(delays) & (delays >= 0) & np.isfinite(amplitudes)
        self.draw_plot("##cir", delays[valid]*1e9, amplitudes[valid], "Retardo absoluto (ns)", "Amplitud |a|", "Caminos", stems=True)

    def draw_plot(self, identifier, x, y, x_label, y_label, series, stems=False):
        plot = self.plot
        x, y = np.ascontiguousarray(x, dtype=np.float64), np.ascontiguousarray(y, dtype=np.float64)
        height = min(self.plot_height, max(85, self.ui.GetContentRegionAvail()[1] - 5))
        if plot.BeginPlot(identifier, (-1, height)):
            plot.SetupAxes(x_label, y_label)
            if stems:
                plot.PlotStems(series, x, y)
            elif len(x) > 1:
                plot.PlotLine(series, x, y)
            else:
                plot.PlotScatter(series, x, y)
            plot.EndPlot()

    @staticmethod
    def status_label(value):
        return {"idle": "Sin calcular", "queued": "En cola", "running": "En curso",
                "succeeded": "Completada", "ready": "Lista", "failed": "Falló",
                "error": "Error", "disconnected": "Desconectada", "stopped": "Detenida",
                "stopping": "Deteniendo", "cancelled": "Cancelada", "outdated": "Escena modificada",
                "replay": "Reproducción", "simulated": "Simulación; sin captura real"}.get(str(value).lower(), str(value))

    def update_gizmo(self):
        actor = next((a for a in self.controller.scene.actors if a.actor_id == self.selected_id), None)
        if actor is None or not self.gizmo_enabled:
            if self.gizmo:
                self.gizmo.set_enabled(False)
            return
        if self.gizmo is None:
            self.gizmo = self.ps.add_transformation_gizmo("Mover actor")
            self.gizmo.set_allow_rotation(False)
            self.gizmo.set_allow_scaling(False)
            self.gizmo.set_interact_in_local_space(False)
        self.gizmo.set_enabled(True)
        if (self.gizmo_actor_id != actor.actor_id or
                self.gizmo_last_position != tuple(actor.position)):
            self.gizmo_actor_id = actor.actor_id
            self.gizmo.set_position(actor.position)
            self.gizmo_last_position = tuple(actor.position)
        position = np.asarray(self.gizmo.get_position(), dtype=float).reshape(3)
        previous = np.asarray(actor.position, dtype=float)
        if not np.allclose(position, previous, atol=1e-5):
            limit = np.asarray(self.controller.scene.room_size)
            position = np.clip(position, 0, limit)
            self.update(actor, "position", tuple(position))
            self.gizmo.set_position(actor.position)
            self.gizmo_last_position = tuple(actor.position)


def run(controller, screenshot_path=None, frame_limit=None):
    """Run the native viewer; bounded frames and UI screenshots support smoke QA."""
    desktop = Desktop(controller)
    try:
        desktop.setup()
        frames = 0
        while not desktop.ps.window_requests_close():
            desktop.ps.frame_tick()
            frames += 1
            if frame_limit is not None and frames >= frame_limit:
                break
        if screenshot_path:
            destination = Path(screenshot_path).resolve()
            destination.parent.mkdir(parents=True, exist_ok=True)
            desktop.ps.screenshot(str(destination), transparent_bg=False, include_UI=True)
    finally:
        try:
            desktop.close_csi()
        finally:
            try:
                controller.close()
            finally:
                desktop.ps.shutdown()
